<?php
return [
  "admin_support_email" => env("ADMIN_SUPPORT_EMAIL")
];