<?php $__env->startComponent('mail::message'); ?>
Bonjour <span><?php echo e($name.' '.$firstname); ?>,</span>

<p><?php echo e($text); ?></p>
<?php $__env->startComponent('mail::button', ['url' => config('app.url'), 'color' => 'success']); ?>
Connexion
<?php if (isset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e)): ?>
<?php $component = $__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e; ?>
<?php unset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

Cordialement,<br>
l'équipe <?php echo e(config('app.name')); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Web\salut\resources\views/emails/messages/newUserMessage.blade.php ENDPATH**/ ?>