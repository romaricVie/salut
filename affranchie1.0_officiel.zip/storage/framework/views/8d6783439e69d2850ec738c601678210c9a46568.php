

 <?php $__env->startSection('content'); ?>
 <div>
    <h1 class="text-center">Gestion de statut du don </h1>
     <div class="max-w-screen-md mx-auto px-3 py-5 mb-3 shadow-sm hover:shadow-md rounded border-2 border-gray-300">
          <span class="font-bold uppercase no-underline "><?php echo e($don->name.' '.$don->firstname); ?></span>
            <i>Enrégistré le <?php echo e($don->created_at); ?></i>
           <div>
            <p><?php echo e($don->nom_produit); ?></p>
           <p class="text-base font-semibold break-all"><?=replace_links(nl2br($don->description))?>
           </p>
              <div class="mb-8">
                  <a href="<?php echo e(asset('storage/'.$don->images)); ?>"><img src="<?php echo e(asset('storage/'.$don->images)); ?>" title="image-don"></a>
              </div>
               <h5><span class="badge badge-<?php echo e($don->status == 'INACTIF' ? 'danger' : 'success'); ?>"><?php echo e($don->status); ?></span></h5>
            </div>
            <div>
            <div class="d-flex justify-content-between">
            <form method="POST" action="<?php echo e(route('admin.update.dons',$don)); ?>">
             <?php echo csrf_field(); ?>
             <?php echo method_field('PATCH'); ?>

              <a href="<?php echo e(route('admin.index.dons')); ?>" class="btn btn-primary mr-2"><i class="fa fa-arrow-left" aria-hidden="true"></i> Retour</a>
              <button type="submit" class="btn btn-success"><i class="fa fa-check-square-o" aria-hidden="true"></i> Appouver</button>
          </form>
      </div>
      </div>
   </div>
</div>
<div class="table-responsive mt-5">
            <table class="table">
             <thead class="thead-dark">
                <tr>
                  <th scope="col">id</th>
                  <th scope="col">Téléphone</th>
                  <th scope="col">Email</th>
                  <th scope="col">Type</th>
                  <th scope="col">Etat_don</th>
                  <th scope="col">Point relais</th>
                 </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>2021<?php echo e($don->id); ?></td>
                    <td><?php echo e($don->phone); ?></td>
                    <td><a href="mailto:<?php echo e($don->email); ?>"><?php echo e($don->email); ?></a></td>
                    <td><?php echo e($don->type); ?></td>
                    <td><?php echo e($don->etat_don); ?></td>
                    <td><?php echo e($don->point_relais); ?></td>
                 </tr>
               </tbody>
            </table>
      </div>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master',['title'=>'Statut-don'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web\salut\resources\views/admin/dons/edit.blade.php ENDPATH**/ ?>