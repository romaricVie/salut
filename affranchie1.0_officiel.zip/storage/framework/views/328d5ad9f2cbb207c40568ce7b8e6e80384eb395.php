

 <?php $__env->startSection('content'); ?>
 <div>
    <h1 class="text-center">Gestion de statut du don </h1>
     <div class="max-w-screen-md mx-auto px-3 py-5 mb-3 shadow-sm hover:shadow-md rounded border-2 border-gray-300">
          <span class="font-bold uppercase no-underline "><?php echo e($donation->name.' '.$donation->firstname); ?></span>
            <i>Enrégistré le <?php echo e($donation->created_at); ?></i>
           <div>
            <p><?php echo e($donation->description); ?></p>
           <p class="text-base font-semibold break-all"><?=replace_links(nl2br($donation->description))?>
           </p>
              <div class="mb-8">
                  <a href="<?php echo e(asset('storage/'.$donation->images)); ?>"><img src="<?php echo e(asset('storage/'.$donation->images)); ?>" title="image-donation"></a>
              </div>
               <h5><span class="badge badge-<?php echo e($donation->status == 'INACTIF' ? 'danger' : 'success'); ?>"><?php echo e($donation->status); ?></span></h5>
            </div>
            <div>
            <div class="d-flex justify-content-between">
            <form method="POST" action="<?php echo e(route('admin.donation.update',$donation)); ?>">
             <?php echo csrf_field(); ?>
             <?php echo method_field('PATCH'); ?>

              <a href="<?php echo e(route('admin.don.invite')); ?>" class="btn btn-primary mr-2"><i class="fa fa-arrow-left" aria-hidden="true"></i> Retour</a>
              <button type="submit" class="btn btn-success"><i class="fa fa-check-square-o" aria-hidden="true"></i> Appouver</button>
          </form>
      </div>
      </div>
   </div>
</div>
<div class="table-responsive mt-5">
            <table class="table">
             <thead class="thead-dark">
                <tr>
                  <th scope="col">id</th>
                  <th scope="col">Téléphone</th>
                  <th scope="col">Email</th>
                  <th scope="col">Type</th>
                  <th scope="col">Etat_don</th>
                  <th scope="col">Point relais</th>
                 </tr>
                </thead>
                <tbody>
                  <tr>
                    <td><?php echo e($donation->id); ?></td>
                    <td><?php echo e($donation->phone); ?></td>
                    <td><a href="mailto:<?php echo e($donation->email); ?>"><?php echo e($donation->email); ?></a></td>
                    <td><?php echo e($donation->type); ?></td>
                    <td><?php echo e($donation->etat_don); ?></td>
                    <td><?php echo e($donation->point_relais); ?></td>
                 </tr>
               </tbody>
            </table>
      </div>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master',['title'=>'Statut-don'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web\salut\resources\views/admin/dons-invites/edit.blade.php ENDPATH**/ ?>