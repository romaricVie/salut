<?php $attributes = $attributes->exceptProps(['disabled' => false]); ?>
<?php foreach (array_filter((['disabled' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<input <?php echo e($disabled ? 'disabled' : ''); ?> <?php echo $attributes->merge(['class' => 'form-input text-sx sm:text-base rounded sm:rounded-md shadow-none block mt-1 bg-gray-200 font-haireline text-sm px-2 sm:px-3 py-1 sm:py-2 border-transparent outline-non  focus:bg-transparent focus:border-red-400 focus:outline-none focus:shadow-none']); ?>>
<?php /**PATH C:\Web\salut\resources\views/vendor/jetstream/components/input.blade.php ENDPATH**/ ?>