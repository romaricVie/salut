 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('title'); ?> Evenements <?php $__env->endSlot(); ?>

  <section class="w-full flex items-center py-4 px-0 flex-col-reverse sm:px-2 md:flex-row md:items-start">
    <!-- Post's section -->
    <section class="w-full text-gray-700">
      <?php if($posts->count() > 0): ?>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('like-post', ['post' => $post])->html();
} elseif ($_instance->childHasBeenRendered('2a6rfGO')) {
    $componentId = $_instance->getRenderedChildComponentId('2a6rfGO');
    $componentTag = $_instance->getRenderedChildComponentTagName('2a6rfGO');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('2a6rfGO');
} else {
    $response = \Livewire\Livewire::mount('like-post', ['post' => $post]);
    $html = $response->html();
    $_instance->logRenderedChild('2a6rfGO', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php else: ?>
     <p> Aucun évènement pour l'instant!</p>
      <?php endif; ?>
    </section>

    <!-- Aside Content -->
    <aside
      id="addingPost"
      class="w-full max-w-xl mb-4 flex-shrink-0 md:sticky md:w-auto md:max-w-auto md:mb-0 md:ml-2 xl:ml-0"
    >
      <form method="POST" enctype="multipart/form-data" id="image-upload-preview" action="<?php echo e(route('evenement.store')); ?>">
        <?php echo csrf_field(); ?>     
        <?php echo $__env->make('partials/_form',['textButton' =>'Soumettre évènement'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </form>
    </aside>
  </section>

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 


<?php /**PATH C:\Web\salut\resources\views/evenements/index.blade.php ENDPATH**/ ?>