
<!-- CRIPTS -->
<script src="<?php echo e(asset('/assets/jquery/jquery-3.5.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/boots/js/bootstrap.min.js')); ?>"></script>

<?php echo \Livewire\Livewire::scripts(); ?>

<?php /**PATH C:\Web\salut\resources\views/template/partials/_footer.blade.php ENDPATH**/ ?>