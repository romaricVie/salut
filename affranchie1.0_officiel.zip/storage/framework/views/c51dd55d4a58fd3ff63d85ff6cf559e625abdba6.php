
<?php $__env->startSection('content'); ?>

  <main class="px-10 pt-10 pb-6">
    
    <div class="flex space-x-5 items-center mb-10">
      <a href="<?php echo e(route('admin.index')); ?>" class="flex-shrink-0 flex items-center text-blue-600 text-xs uppercase m-0">
        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
        <span>Retour</span>
      </a>
      <h1 class="text-xl font-extrabold text-gray-700">Edition des roles</h1>
    </div>

    <section class="bg-white p-4 rounded-md">
      <h3 class="text-base font-bold text-gray-600 mb-3">Modifier le rôle de l'adresse <b>#<a href="mailto:<?php echo e($user->email); ?>"><?php echo e($user->email); ?></a></h3>

      <div>
        <form method="POST" action="<?php echo e(route('admin.update',$user)); ?>" class="pl-3">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PATCH'); ?>
          
          <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="form-group m-0">
              <!-- Name est un tableaux de role -->
              <input 
                type="radio" 
                class="w-4 h-4" 
                name="roles[]" 
                value="<?php echo e($role->id); ?>" 
                id="<?php echo e($role->id); ?>" <?php if($user->roles->pluck('id')->contains($role->id)): ?> checked <?php endif; ?>
              >
              <label for="<?php echo e($role->id); ?>" class="text-sm font-normal text-gray-600"><?php echo e($role->name); ?></label>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <button type="submit" class="btn btn-success text-sm mt-3">Modifier le rôle</button>

         </form>
      </div>
    </section>

  </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master',['title'=>'Roles - '.$user->name], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web\salut\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>