
<header>
    <template x-if="window.outerWidth >= 640">
        <section class="w-full flex items-center justify-between h-full">
            <div class="flex items-center flex-shrink-0">
                <template x-if="1280 >= window.outerWidth">
                    <span 
                        @click="showSidemenu = !showSidemenu"
                        class="mr-3 text-red-600"
                    >
                        <svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="bars" class="w-8 h-8" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path fill="currentColor" d="M16 132h416c8.837 0 16-7.163 16-16V76c0-8.837-7.163-16-16-16H16C7.163 60 0 67.163 0 76v40c0 8.837 7.163 16 16 16zm0 160h416c8.837 0 16-7.163 16-16v-40c0-8.837-7.163-16-16-16H16c-8.837 0-16 7.163-16 16v40c0 8.837 7.163 16 16 16zm0 160h416c8.837 0 16-7.163 16-16v-40c0-8.837-7.163-16-16-16H16c-8.837 0-16 7.163-16 16v40c0 8.837 7.163 16 16 16z"></path></svg>
                    </span>
                </template>

                <a href=""><img src="/images/logo.png" alt="Logo affranchie" class="h-12 w-auto"></a>

                <div class="h-10 flex items-center justify-center px-2 ml-2 rounded-full overflow-hidden text-gray-500 bg-gray-200">
                    <label for="memberSearch" class="flex-shrink-0 cursor-text px-1">
                        <svg class="w-5 h-5" fill="currentColor" height="96px" id="magnifying_glass" version="1.1" viewBox="0 0 96 96" width="96px" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><path d="M90.63,84.971l-22.5-22.5C73.05,56.311,76,48.5,76,40C76,20.12,59.88,4,40,4S4,20.12,4,40  s16.12,36,36,36c8.5,0,16.311-2.95,22.471-7.87l22.5,22.5c0.779,0.78,1.812,1.17,2.829,1.17c1.021,0,2.05-0.39,2.83-1.17  C92.189,89.07,92.189,86.529,90.63,84.971z M40,68c-15.464,0-28-12.536-28-28s12.536-28,28-28s28,12.536,28,28S55.464,68,40,68z" id="_x3C_Path_x3E_"/></svg>
                    </label>
                    <input 
                        class="w-0 outline-none bg-transparent lg:w-56 lg:h-full lg:py-2 lg:pl-1 focus:text-gray-600"
                        type="text" 
                        name="memberSearch" 
                        id="memberSearch"
                        placeholder="Chercher un membre"
                    >
                </div>
            </div>

            <div class="xl:transform xl:-translate-x-1/2">
                <ul class="flex items-center text-gray-600">
                    <li>
                        <a 
                            href="" 
                            aria-label="Accueil"
                            data-title="Accueil"
                            class="w-12 h-12 p-1 grid place-items-center rounded-md lg:w-20 lg:rounded-lg hover:bg-red-200 hover:text-red-600 main__link"
                        >
                            <svg class="w-8 h-8" fill="currentColor" baseProfile="tiny" height="24px" id="Layer_1" version="1.2" viewBox="0 0 24 24" width="24px" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><path d="M12,3c0,0-6.186,5.34-9.643,8.232C2.154,11.416,2,11.684,2,12c0,0.553,0.447,1,1,1h2v7c0,0.553,0.447,1,1,1h3  c0.553,0,1-0.448,1-1v-4h4v4c0,0.552,0.447,1,1,1h3c0.553,0,1-0.447,1-1v-7h2c0.553,0,1-0.447,1-1c0-0.316-0.154-0.584-0.383-0.768  C18.184,8.34,12,3,12,3z"/></svg>
                        </a>
                    </li>
                    <li class="mx-1 lg:mx-0">
                        <a 
                            href="" 
                            aria-label="Je fais dons"
                            data-title="Je fais dons"
                            class="w-12 h-12 p-1 grid place-items-center rounded-md lg:w-20 lg:rounded-lg hover:bg-red-200 hover:text-red-600 main__link"
                        >
                        <svg class="w-8 h-8" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="hand-holding-heart" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><path fill="currentColor" d="M275.3 250.5c7 7.4 18.4 7.4 25.5 0l108.9-114.2c31.6-33.2 29.8-88.2-5.6-118.8-30.8-26.7-76.7-21.9-104.9 7.7L288 36.9l-11.1-11.6C248.7-4.4 202.8-9.2 172 17.5c-35.3 30.6-37.2 85.6-5.6 118.8l108.9 114.2zm290 77.6c-11.8-10.7-30.2-10-42.6 0L430.3 402c-11.3 9.1-25.4 14-40 14H272c-8.8 0-16-7.2-16-16s7.2-16 16-16h78.3c15.9 0 30.7-10.9 33.3-26.6 3.3-20-12.1-37.4-31.6-37.4H192c-27 0-53.1 9.3-74.1 26.3L71.4 384H16c-8.8 0-16 7.2-16 16v96c0 8.8 7.2 16 16 16h356.8c14.5 0 28.6-4.9 40-14L564 377c15.2-12.1 16.4-35.3 1.3-48.9z"></path></svg>
                        </a>
                    </li>
                    <li>
                        <a 
                            href="" 
                            aria-label="Membres"
                            data-title="Membres"
                            class="w-12 h-12 p-1 grid place-items-center rounded-md lg:w-20 lg:rounded-lg hover:bg-red-200 hover:text-red-600 main__link"
                        >
                        <svg class="w-8 h-8" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="users" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512"><path fill="currentColor" d="M96 224c35.3 0 64-28.7 64-64s-28.7-64-64-64-64 28.7-64 64 28.7 64 64 64zm448 0c35.3 0 64-28.7 64-64s-28.7-64-64-64-64 28.7-64 64 28.7 64 64 64zm32 32h-64c-17.6 0-33.5 7.1-45.1 18.6 40.3 22.1 68.9 62 75.1 109.4h66c17.7 0 32-14.3 32-32v-32c0-35.3-28.7-64-64-64zm-256 0c61.9 0 112-50.1 112-112S381.9 32 320 32 208 82.1 208 144s50.1 112 112 112zm76.8 32h-8.3c-20.8 10-43.9 16-68.5 16s-47.6-6-68.5-16h-8.3C179.6 288 128 339.6 128 403.2V432c0 26.5 21.5 48 48 48h288c26.5 0 48-21.5 48-48v-28.8c0-63.6-51.6-115.2-115.2-115.2zm-223.7-13.4C161.5 263.1 145.6 256 128 256H64c-35.3 0-64 28.7-64 64v32c0 17.7 14.3 32 32 32h65.9c6.3-47.4 34.9-87.3 75.2-109.4z"></path></svg>
                        </a>
                    </li>
                </ul>
            </div>
            
            <div>
                <ul class="flex items-center text-gray-700">
                    <li class="mr-3" x-data="{ isOpen: false }">
                        <button 
                            aria-label="Créer"
                            data-title="Créer"
                            class="w-8 h-8 grid place-items-center rounded-full bg-gray-200 lg:w-10 lg:h-10 hover:bg-red-200 hover:text-red-600 main__link"
                            @click="isOpen = !isOpen"
                        >
                            <svg class="w-5 h-5" height="32px" id="Layer_1" fill="currentColor" version="1.1" viewBox="0 0 32 32" width="32px" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><path d="M28,14H18V4c0-1.104-0.896-2-2-2s-2,0.896-2,2v10H4c-1.104,0-2,0.896-2,2s0.896,2,2,2h10v10c0,1.104,0.896,2,2,2  s2-0.896,2-2V18h10c1.104,0,2-0.896,2-2S29.104,14,28,14z"/></svg>
                        </button>
                        <article 
                            class="dropdown__content block fixed right-0 bg-white shadow-lg rounded px-2 py-4"
                            x-show="isOpen"
                            :aria-hidden="!isOpen"
                            :hidden="!isOpen"
                            @click.away="isOpen = false"
                        >
                            <h1 class="text-xl font-bold text-gray-900 mb-4 px-2">Créer</h1>
                            <ul>
                                <li class="mb-1">
                                    <a href="" class="w-full block rounded p-2 flex items-start hover:bg-gray-200">
                                        <span class="w-10 h-10 rounded-full grid place-items-center flex-shrink-0 mr-2 bg-gray-400 text-gray-900">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6" width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path transform="rotate(45.001 19.345 4.656)" d="M17.223 3.039H21.466V6.273H17.223z"></path><path d="M8 16L11 16 18.287 8.713 15.287 5.713 8 13z"></path><path d="M19,19H8.158c-0.026,0-0.053,0.01-0.079,0.01c-0.033,0-0.066-0.009-0.1-0.01H5V5h6.847l2-2H5C3.897,3,3,3.896,3,5v14 c0,1.104,0.897,2,2,2h14c1.104,0,2-0.896,2-2v-8.668l-2,2V19z"></path></svg>
                                        </span>
                                        <div>
                                            <p class="text-lg text-gray-900 font-semibold">Publication</p>
                                            <p class="text-sm">Partagez une publication sur le fil d'actualité</p>
                                        </div>
                                    </a>
                                </li>
                                <li class="mb-1">
                                    <a href="" class="w-full block rounded p-2 flex items-start hover:bg-gray-200">
                                        <span class="w-10 h-10 rounded-full grid place-items-center flex-shrink-0 mr-2 bg-gray-400 text-gray-900">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6" aria-hidden="true" focusable="false" role="img" width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M20.664 3.478L8 8v7l.748.267-1.127 2.254c-.26.519-.281 1.123-.06 1.659.223.536.665.949 1.216 1.133l4.084 1.361c.205.068.416.101.624.101.741 0 1.451-.414 1.797-1.104l1.303-2.606 4.079 1.457c.65.233 1.336-.25 1.336-.941V4.419C22 3.728 21.314 3.245 20.664 3.478zM13.493 19.777L9.41 18.416l1.235-2.471 4.042 1.444L13.493 19.777zM4 15h2V8H4c-1.103 0-2 .897-2 2v3C2 14.103 2.897 15 4 15z"></path></svg>
                                        </span>
                                        <div>
                                            <p class="text-lg text-gray-900 font-semibold">Témoignage</p>
                                            <p class="text-sm">Partagez votre témoignage pour édifier quelqu'un qui traverse votre situation</p>
                                        </div>
                                    </a>
                                </li><li class="mb-1">
                                    <a href="" class="w-full block rounded p-2 flex items-start hover:bg-gray-200">
                                        <span class="w-10 h-10 rounded-full grid place-items-center flex-shrink-0 mr-2 bg-gray-400 text-gray-900">
                                            <svg class="w-6 h-6" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="book-open" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><path fill="currentColor" d="M542.22 32.05c-54.8 3.11-163.72 14.43-230.96 55.59-4.64 2.84-7.27 7.89-7.27 13.17v363.87c0 11.55 12.63 18.85 23.28 13.49 69.18-34.82 169.23-44.32 218.7-46.92 16.89-.89 30.02-14.43 30.02-30.66V62.75c.01-17.71-15.35-31.74-33.77-30.7zM264.73 87.64C197.5 46.48 88.58 35.17 33.78 32.05 15.36 31.01 0 45.04 0 62.75V400.6c0 16.24 13.13 29.78 30.02 30.66 49.49 2.6 149.59 12.11 218.77 46.95 10.62 5.35 23.21-1.94 23.21-13.46V100.63c0-5.29-2.62-10.14-7.27-12.99z"></path></svg>
                                        </span>
                                        <div>
                                            <p class="text-lg text-gray-900 font-semibold">Enseignement</p>
                                            <p class="text-sm">Partagez votre témoignage pour édifier quelqu'un qui traverse votre situation</p>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a href="" class="w-full block rounded p-2 flex items-start hover:bg-gray-200">
                                        <span class="w-10 h-10 rounded-full grid place-items-center flex-shrink-0 mr-2 bg-gray-400 text-gray-900">
                                            <svg class="w-6 h-6" aria-hidden="true" focusable="false" data-prefix="far" data-icon="calendar-alt" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path fill="currentColor" d="M148 288h-40c-6.6 0-12-5.4-12-12v-40c0-6.6 5.4-12 12-12h40c6.6 0 12 5.4 12 12v40c0 6.6-5.4 12-12 12zm108-12v-40c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v40c0 6.6 5.4 12 12 12h40c6.6 0 12-5.4 12-12zm96 0v-40c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v40c0 6.6 5.4 12 12 12h40c6.6 0 12-5.4 12-12zm-96 96v-40c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v40c0 6.6 5.4 12 12 12h40c6.6 0 12-5.4 12-12zm-96 0v-40c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v40c0 6.6 5.4 12 12 12h40c6.6 0 12-5.4 12-12zm192 0v-40c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v40c0 6.6 5.4 12 12 12h40c6.6 0 12-5.4 12-12zm96-260v352c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V112c0-26.5 21.5-48 48-48h48V12c0-6.6 5.4-12 12-12h40c6.6 0 12 5.4 12 12v52h128V12c0-6.6 5.4-12 12-12h40c6.6 0 12 5.4 12 12v52h48c26.5 0 48 21.5 48 48zm-48 346V160H48v298c0 3.3 2.7 6 6 6h340c3.3 0 6-2.7 6-6z"></path></svg>
                                        </span>
                                        <div>
                                            <p class="text-lg text-gray-900 font-semibold">Evènement</p>
                                            <p class="text-sm">Partagez votre témoignage pour édifier quelqu'un qui traverse votre situation</p>
                                        </div>
                                    </a>
                                </li>
                            </ul>
                        </article>
                    </li>
                    <li class="mr-3" x-data="{ isOpen: false }">
                        <button  
                            aria-label="Notifications"
                            data-title="Notifications"
                            class="w-8 h-8 grid place-items-center rounded-full bg-gray-200 lg:w-10 lg:h-10 hover:bg-red-200 hover:text-red-600 main__link"
                            @click="isOpen = !isOpen"
                        >
                            <svg class="w-5 h-5" fill="currentColor" version="1.1" viewBox="0 0 24 24" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><g id="info"/><g id="icons"><g id="notification"><path d="M13.7,20h-3.5c-0.7,0-1.3,0.8-0.9,1.5C9.9,22.4,10.9,23,12,23s2.1-0.6,2.6-1.5C15,20.8,14.5,20,13.7,20z"/><path d="M21.8,16.7l-0.4-0.5C19.8,14.1,19,11.6,19,9V8.3c0-3.6-2.6-6.8-6.2-7.2C8.6,0.6,5,3.9,5,8v1c0,2.6-0.8,5.1-2.4,7.2    l-0.4,0.5c-0.2,0.2-0.3,0.6-0.2,0.8C2.3,18.4,3.1,19,4,19h16c0.9,0,1.7-0.6,1.9-1.5C22,17.2,21.9,16.9,21.8,16.7z"/></g></g></svg>
                        </button>
                        <article 
                            class="dropdown__content block fixed right-0 transform bg-white shadow-lg rounded px-2 py-4"
                            x-show="isOpen"
                            :aria-hidden="!isOpen"
                            :hidden="!isOpen"
                            @click.away="isOpen = false"
                        >
                            <h1 class="text-xl font-bold text-gray-900 mb-4 px-2">Notifications</h1>
                            <ul class="h-64 overflow-y-auto">
                                <li class="mb-1">
                                    <a href="" class="w-full block rounded p-2 flex items-start hover:bg-gray-200">
                                        <span class="w-10 h-10 rounded-full grid place-items-center flex-shrink-0 mr-2 bg-gray-400 text-gray-900">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" aria-hidden="true" focusable="false" role="img" width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M20.664 3.478L8 8v7l.748.267-1.127 2.254c-.26.519-.281 1.123-.06 1.659.223.536.665.949 1.216 1.133l4.084 1.361c.205.068.416.101.624.101.741 0 1.451-.414 1.797-1.104l1.303-2.606 4.079 1.457c.65.233 1.336-.25 1.336-.941V4.419C22 3.728 21.314 3.245 20.664 3.478zM13.493 19.777L9.41 18.416l1.235-2.471 4.042 1.444L13.493 19.777zM4 15h2V8H4c-1.103 0-2 .897-2 2v3C2 14.103 2.897 15 4 15z"></path></svg>
                                        </span>
                                        <div>
                                            <p class="text-sm text-gray-900"><span class="font-bold text-md">Hudson Marques</span> a partagé un nouveau témoignage</p>
                                            <p class="text-xs">Il y a 13 minutes</p>
                                        </div>
                                    </a>
                                </li>
                                <li class="mb-1">
                                    <a href="" class="w-full block rounded p-2 flex items-start hover:bg-gray-200">
                                        <span class="w-10 h-10 rounded-full grid place-items-center flex-shrink-0 mr-2 bg-gray-400 text-gray-900">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path transform="rotate(45.001 19.345 4.656)" d="M17.223 3.039H21.466V6.273H17.223z"></path><path d="M8 16L11 16 18.287 8.713 15.287 5.713 8 13z"></path><path d="M19,19H8.158c-0.026,0-0.053,0.01-0.079,0.01c-0.033,0-0.066-0.009-0.1-0.01H5V5h6.847l2-2H5C3.897,3,3,3.896,3,5v14 c0,1.104,0.897,2,2,2h14c1.104,0,2-0.896,2-2v-8.668l-2,2V19z"></path></svg>
                                        </span>
                                        <div>
                                            <p class="text-sm text-gray-900"><span class="font-bold text-md">Andrea Piacquadio</span> votre publication a été aprouvée.</p>
                                            <p class="text-xs">Il y a 15 minutes</p>
                                        </div>
                                    </a>
                                </li>
                                <li class="mb-1">
                                    <a href="" class="w-full block rounded p-2 flex items-start hover:bg-gray-200">
                                        <span class="w-10 h-10 rounded-full grid place-items-center flex-shrink-0 mr-2 bg-gray-400 text-gray-900">
                                            <svg class="w-5 h-5" aria-hidden="true" focusable="false" data-prefix="far" data-icon="calendar-alt" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path fill="currentColor" d="M148 288h-40c-6.6 0-12-5.4-12-12v-40c0-6.6 5.4-12 12-12h40c6.6 0 12 5.4 12 12v40c0 6.6-5.4 12-12 12zm108-12v-40c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v40c0 6.6 5.4 12 12 12h40c6.6 0 12-5.4 12-12zm96 0v-40c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v40c0 6.6 5.4 12 12 12h40c6.6 0 12-5.4 12-12zm-96 96v-40c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v40c0 6.6 5.4 12 12 12h40c6.6 0 12-5.4 12-12zm-96 0v-40c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v40c0 6.6 5.4 12 12 12h40c6.6 0 12-5.4 12-12zm192 0v-40c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v40c0 6.6 5.4 12 12 12h40c6.6 0 12-5.4 12-12zm96-260v352c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V112c0-26.5 21.5-48 48-48h48V12c0-6.6 5.4-12 12-12h40c6.6 0 12 5.4 12 12v52h128V12c0-6.6 5.4-12 12-12h40c6.6 0 12 5.4 12 12v52h48c26.5 0 48 21.5 48 48zm-48 346V160H48v298c0 3.3 2.7 6 6 6h340c3.3 0 6-2.7 6-6z"></path></svg>
                                        </span>
                                        <div>
                                            <p class="text-sm text-gray-900"><span class="font-bold text-md">Tony James-Andersson</span> a ajouté un nouvel évènement</p>
                                            <p class="text-xs">Il y a 15 minutes</p>
                                        </div>
                                    </a>
                                </li>
                            </ul>
                        </article>
                    </li>
                    <li class="mr-4" x-data="{ isOpen: false }">
                        <button  
                            aria-label="Mon Compte"
                            data-title="Mon Compte"
                            class="w-8 h-8 grid place-items-center rounded-full border-2 lg:w-10 lg:h-10 bg-gray-200 hover:bg-red-200 hover:text-red-600 main__link"
                            @click="isOpen = !isOpen"
                        >
                            <img 
                                src="/images/user/pexels-andrea-piacquadio-3907440.jpg" 
                                alt="photo de profil de Andrea Piacquadio" 
                                class="w-full h-full rounded-full object-center object-scale-down"
                            />
                        </button>
                        <article 
                            class="dropdown__content block fixed right-0 transform bg-white shadow-lg rounded px-2 py-4"
                            x-show="isOpen"
                            :aria-hidden="!isOpen"
                            :hidden="!isOpen"
                            @click.away="isOpen = false"
                        >
                            <h1 class="text-xl font-bold text-gray-900 mb-4 px-2">Mon Compte</h1>
                            <ul>
                                <li class="mb-1">
                                    <a href="" class="w-full block rounded p-2 flex items-center hover:bg-gray-200">
                                        <span class="w-10 h-10 rounded-full grid place-items-center flex-shrink-0 mr-2 bg-gray-400 text-gray-900">
                                            <svg class="w-5 h-5" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="user" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path fill="currentColor" d="M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0 96 57.3 96 128s57.3 128 128 128zm89.6 32h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48v-41.6c0-74.2-60.2-134.4-134.4-134.4z"></path></svg>
                                        </span>
                                        <p class="text-lg font-semibold text-gray-900">Mon profil</p>
                                    </a>
                                </li>
                                <li class="mb-1">
                                    <a href="" class="w-full block rounded p-2 flex items-center hover:bg-gray-200">
                                        <span class="w-10 h-10 rounded-full grid place-items-center flex-shrink-0 mr-2 bg-gray-400 text-gray-900">
                                            <svg class="w-5 h-5" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="user-edit" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512"><path fill="currentColor" d="M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0 96 57.3 96 128s57.3 128 128 128zm89.6 32h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h274.9c-2.4-6.8-3.4-14-2.6-21.3l6.8-60.9 1.2-11.1 7.9-7.9 77.3-77.3c-24.5-27.7-60-45.5-99.9-45.5zm45.3 145.3l-6.8 61c-1.1 10.2 7.5 18.8 17.6 17.6l60.9-6.8 137.9-137.9-71.7-71.7-137.9 137.8zM633 268.9L595.1 231c-9.3-9.3-24.5-9.3-33.8 0l-37.8 37.8-4.1 4.1 71.8 71.7 41.8-41.8c9.3-9.4 9.3-24.5 0-33.9z"></path></svg>
                                        </span>
                                        <p class="text-lg font-semibold text-gray-900">Editer mon profil</p>
                                    </a>
                                </li>
                                <li class="mb-1">
                                    <a href="" class="w-full block rounded p-2 flex items-center hover:bg-gray-200">
                                        <span class="w-10 h-10 rounded-full grid place-items-center flex-shrink-0 mr-2 bg-gray-400 text-gray-900">
                                            <svg class="w-5 h-5" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="cross" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><path fill="currentColor" d="M352 128h-96V32c0-17.67-14.33-32-32-32h-64c-17.67 0-32 14.33-32 32v96H32c-17.67 0-32 14.33-32 32v64c0 17.67 14.33 32 32 32h96v224c0 17.67 14.33 32 32 32h64c17.67 0 32-14.33 32-32V256h96c17.67 0 32-14.33 32-32v-64c0-17.67-14.33-32-32-32z"></path></svg>
                                        </span>
                                        <p class="text-lg font-semibold text-gray-900">J'accepte Jésus-Christ</p>
                                    </a>
                                </li>
                                <li class="mb-1">
                                    <a href="" class="w-full block rounded p-2 flex items-center hover:bg-gray-200">
                                        <span class="w-10 h-10 rounded-full grid place-items-center flex-shrink-0 mr-2 bg-gray-400 text-gray-900">
                                            <svg class="w-5 h-5" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="users-cog" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512"><path fill="currentColor" d="M610.5 341.3c2.6-14.1 2.6-28.5 0-42.6l25.8-14.9c3-1.7 4.3-5.2 3.3-8.5-6.7-21.6-18.2-41.2-33.2-57.4-2.3-2.5-6-3.1-9-1.4l-25.8 14.9c-10.9-9.3-23.4-16.5-36.9-21.3v-29.8c0-3.4-2.4-6.4-5.7-7.1-22.3-5-45-4.8-66.2 0-3.3.7-5.7 3.7-5.7 7.1v29.8c-13.5 4.8-26 12-36.9 21.3l-25.8-14.9c-2.9-1.7-6.7-1.1-9 1.4-15 16.2-26.5 35.8-33.2 57.4-1 3.3.4 6.8 3.3 8.5l25.8 14.9c-2.6 14.1-2.6 28.5 0 42.6l-25.8 14.9c-3 1.7-4.3 5.2-3.3 8.5 6.7 21.6 18.2 41.1 33.2 57.4 2.3 2.5 6 3.1 9 1.4l25.8-14.9c10.9 9.3 23.4 16.5 36.9 21.3v29.8c0 3.4 2.4 6.4 5.7 7.1 22.3 5 45 4.8 66.2 0 3.3-.7 5.7-3.7 5.7-7.1v-29.8c13.5-4.8 26-12 36.9-21.3l25.8 14.9c2.9 1.7 6.7 1.1 9-1.4 15-16.2 26.5-35.8 33.2-57.4 1-3.3-.4-6.8-3.3-8.5l-25.8-14.9zM496 368.5c-26.8 0-48.5-21.8-48.5-48.5s21.8-48.5 48.5-48.5 48.5 21.8 48.5 48.5-21.7 48.5-48.5 48.5zM96 224c35.3 0 64-28.7 64-64s-28.7-64-64-64-64 28.7-64 64 28.7 64 64 64zm224 32c1.9 0 3.7-.5 5.6-.6 8.3-21.7 20.5-42.1 36.3-59.2 7.4-8 17.9-12.6 28.9-12.6 6.9 0 13.7 1.8 19.6 5.3l7.9 4.6c.8-.5 1.6-.9 2.4-1.4 7-14.6 11.2-30.8 11.2-48 0-61.9-50.1-112-112-112S208 82.1 208 144c0 61.9 50.1 112 112 112zm105.2 194.5c-2.3-1.2-4.6-2.6-6.8-3.9-8.2 4.8-15.3 9.8-27.5 9.8-10.9 0-21.4-4.6-28.9-12.6-18.3-19.8-32.3-43.9-40.2-69.6-10.7-34.5 24.9-49.7 25.8-50.3-.1-2.6-.1-5.2 0-7.8l-7.9-4.6c-3.8-2.2-7-5-9.8-8.1-3.3.2-6.5.6-9.8.6-24.6 0-47.6-6-68.5-16h-8.3C179.6 288 128 339.6 128 403.2V432c0 26.5 21.5 48 48 48h255.4c-3.7-6-6.2-12.8-6.2-20.3v-9.2zM173.1 274.6C161.5 263.1 145.6 256 128 256H64c-35.3 0-64 28.7-64 64v32c0 17.7 14.3 32 32 32h65.9c6.3-47.4 34.9-87.3 75.2-109.4z"></path></svg>
                                        </span>
                                        <p class="text-lg font-semibold text-gray-900">Administration</p>
                                    </a>
                                </li>
                                <li class="border-t-2 pt-2">
                                    <a href="" class="w-full block rounded p-2 flex items-center hover:bg-gray-200">
                                        <span class="w-10 h-10 rounded-full grid place-items-center flex-shrink-0 mr-2 bg-gray-400 text-gray-900">
                                            <svg class="w-5 h-5" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" role="img" width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M16 13L16 11 7 11 7 8 2 12 7 16 7 13z"></path><path d="M20,3h-9C9.897,3,9,3.897,9,5v4h2V5h9v14h-9v-4H9v4c0,1.103,0.897,2,2,2h9c1.103,0,2-0.897,2-2V5C22,3.897,21.103,3,20,3z"></path></svg>
                                        </span>
                                        <p class="text-lg text-gray-900 font-semibold">Déconnexion</p>
                                    </a>
                                </li>
                            </ul>
                        </article>
                    </li>
                </ul>
            </div>
        </section>
    </template>

    <template x-if="640 > window.outerWidth">
        <section class="w-full h-full flex items-center justify-between">
            <a href=""><img src="/images/logo.png" alt="Logo affranchie" class="h-8 w-auto"></a>
            <div class="flex items-center -mr-2">
                <div class="w-8 h-8 grid place-items-center rounded-full bg-white">
                    <label for="memberSearch" class="flex-shrink-0 cursor-text px-1">
                        <svg class="w-5 h-5 text-gray-600" fill="currentColor" id="magnifying_glass" version="1.1" viewBox="0 0 96 96" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><path d="M90.63,84.971l-22.5-22.5C73.05,56.311,76,48.5,76,40C76,20.12,59.88,4,40,4S4,20.12,4,40  s16.12,36,36,36c8.5,0,16.311-2.95,22.471-7.87l22.5,22.5c0.779,0.78,1.812,1.17,2.829,1.17c1.021,0,2.05-0.39,2.83-1.17  C92.189,89.07,92.189,86.529,90.63,84.971z M40,68c-15.464,0-28-12.536-28-28s12.536-28,28-28s28,12.536,28,28S55.464,68,40,68z" id="_x3C_Path_x3E_"/></svg>
                    </label>
                    <input 
                        class="hidden w-0 outline-none bg-transparent lg:w-56 lg:h-full lg:py-2 lg:pl-1 focus:text-gray-600"
                        type="text" 
                        name="memberSearch" 
                        id="memberSearch"
                        placeholder="Chercher un membre"
                    >
                </div>
                <div 
                    x-data="{ isOpen: false }"
                    class="mx-2"
                >
                    <button  
                        aria-label="Notifications"
                        class="w-8 h-8 grid place-items-center rounded-full bg-white text-gray-600"
                        @click="isOpen = !isOpen"
                    >
                        <svg class="w-5 h-5" fill="currentColor" version="1.1" viewBox="0 0 24 24" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><g id="info"/><g id="icons"><g id="notification"><path d="M13.7,20h-3.5c-0.7,0-1.3,0.8-0.9,1.5C9.9,22.4,10.9,23,12,23s2.1-0.6,2.6-1.5C15,20.8,14.5,20,13.7,20z"/><path d="M21.8,16.7l-0.4-0.5C19.8,14.1,19,11.6,19,9V8.3c0-3.6-2.6-6.8-6.2-7.2C8.6,0.6,5,3.9,5,8v1c0,2.6-0.8,5.1-2.4,7.2    l-0.4,0.5c-0.2,0.2-0.3,0.6-0.2,0.8C2.3,18.4,3.1,19,4,19h16c0.9,0,1.7-0.6,1.9-1.5C22,17.2,21.9,16.9,21.8,16.7z"/></g></g></svg>
                    </button>
                    <article 
                        class="xs__dropdown__content flex flex-col fixed right-0 bg-white px-2 py-2 border rounded-b-md"
                        x-show="isOpen"
                        :aria-hidden="!isOpen"
                        :hidden="!isOpen"
                        @click.away="isOpen = false"
                    >
                        <h1 class="flex-shrink-0 text-lg font-bold text-gray-900 mb-2 px-2">Notifications</h1>
                        <ul class="h-full overflow-y-auto">
                            <li class="mb-1">
                                <a href="" class="w-full block rounded p-2 flex items-start hover:bg-gray-200">
                                    <span class="w-8 h-8 rounded-full grid place-items-center flex-shrink-0 mr-2 bg-gray-400 text-gray-900">
                                        <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" aria-hidden="true" focusable="false" role="img" width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M20.664 3.478L8 8v7l.748.267-1.127 2.254c-.26.519-.281 1.123-.06 1.659.223.536.665.949 1.216 1.133l4.084 1.361c.205.068.416.101.624.101.741 0 1.451-.414 1.797-1.104l1.303-2.606 4.079 1.457c.65.233 1.336-.25 1.336-.941V4.419C22 3.728 21.314 3.245 20.664 3.478zM13.493 19.777L9.41 18.416l1.235-2.471 4.042 1.444L13.493 19.777zM4 15h2V8H4c-1.103 0-2 .897-2 2v3C2 14.103 2.897 15 4 15z"></path></svg>
                                    </span>
                                    <div>
                                        <p class="text-sm text-gray-900"><span class="font-bold text-md">Hudson Marques</span> a partagé un nouveau témoignage</p>
                                        <p class="text-xs">Il y a 13 minutes</p>
                                    </div>
                                </a>
                            </li>
                            <li class="mb-1">
                                <a href="" class="w-full block rounded p-2 flex items-start hover:bg-gray-200">
                                    <span class="w-8 h-8 rounded-full grid place-items-center flex-shrink-0 mr-2 bg-gray-400 text-gray-900">
                                        <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path transform="rotate(45.001 19.345 4.656)" d="M17.223 3.039H21.466V6.273H17.223z"></path><path d="M8 16L11 16 18.287 8.713 15.287 5.713 8 13z"></path><path d="M19,19H8.158c-0.026,0-0.053,0.01-0.079,0.01c-0.033,0-0.066-0.009-0.1-0.01H5V5h6.847l2-2H5C3.897,3,3,3.896,3,5v14 c0,1.104,0.897,2,2,2h14c1.104,0,2-0.896,2-2v-8.668l-2,2V19z"></path></svg>
                                    </span>
                                    <div>
                                        <p class="text-sm text-gray-900"><span class="font-bold text-md">Andrea Piacquadio</span> votre publication a été aprouvée.</p>
                                        <p class="text-xs">Il y a 15 minutes</p>
                                    </div>
                                </a>
                            </li>
                            <li class="mb-1">
                                <a href="" class="w-full block rounded p-2 flex items-start hover:bg-gray-200">
                                    <span class="w-8 h-8 rounded-full grid place-items-center flex-shrink-0 mr-2 bg-gray-400 text-gray-900">
                                        <svg class="w-5 h-5" aria-hidden="true" focusable="false" data-prefix="far" data-icon="calendar-alt" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path fill="currentColor" d="M148 288h-40c-6.6 0-12-5.4-12-12v-40c0-6.6 5.4-12 12-12h40c6.6 0 12 5.4 12 12v40c0 6.6-5.4 12-12 12zm108-12v-40c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v40c0 6.6 5.4 12 12 12h40c6.6 0 12-5.4 12-12zm96 0v-40c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v40c0 6.6 5.4 12 12 12h40c6.6 0 12-5.4 12-12zm-96 96v-40c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v40c0 6.6 5.4 12 12 12h40c6.6 0 12-5.4 12-12zm-96 0v-40c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v40c0 6.6 5.4 12 12 12h40c6.6 0 12-5.4 12-12zm192 0v-40c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v40c0 6.6 5.4 12 12 12h40c6.6 0 12-5.4 12-12zm96-260v352c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V112c0-26.5 21.5-48 48-48h48V12c0-6.6 5.4-12 12-12h40c6.6 0 12 5.4 12 12v52h128V12c0-6.6 5.4-12 12-12h40c6.6 0 12 5.4 12 12v52h48c26.5 0 48 21.5 48 48zm-48 346V160H48v298c0 3.3 2.7 6 6 6h340c3.3 0 6-2.7 6-6z"></path></svg>
                                    </span>
                                    <div>
                                        <p class="text-sm text-gray-900"><span class="font-bold text-md">Tony James-Andersson</span> a ajouté un nouvel évènement</p>
                                        <p class="text-xs">Il y a 15 minutes</p>
                                    </div>
                                </a>
                            </li>
                        </ul>
                    </article>
                </div>
                <span 
                    @click="showSidemenu = !showSidemenu"
                    class="w-6 grid place-items-center text-gray-600 flex-shrink-0"
                >
                    <svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="ellipsis-v" class="w-auto h-5" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 192 512"><path fill="currentColor" d="M96 184c39.8 0 72 32.2 72 72s-32.2 72-72 72-72-32.2-72-72 32.2-72 72-72zM24 80c0 39.8 32.2 72 72 72s72-32.2 72-72S135.8 8 96 8 24 40.2 24 80zm0 352c0 39.8 32.2 72 72 72s72-32.2 72-72-32.2-72-72-72-72 32.2-72 72z"></path></svg>
                </span>
            </div>
            <nav class="w-full h-12 fixed bottom-0 left-0 flex items-center bg-white px-3 xs__navbar__menu">
                <ul class="w-full flex items-center justify-between">
                    <li>
                        <a 
                            href="" 
                            aria-label="Accueil"
                            class="text-gray-600"
                        >
                            <svg class="w-6 h-6" fill="currentColor" baseProfile="tiny" height="24px" id="Layer_1" version="1.2" viewBox="0 0 24 24" width="24px" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><path d="M12,3c0,0-6.186,5.34-9.643,8.232C2.154,11.416,2,11.684,2,12c0,0.553,0.447,1,1,1h2v7c0,0.553,0.447,1,1,1h3  c0.553,0,1-0.448,1-1v-4h4v4c0,0.552,0.447,1,1,1h3c0.553,0,1-0.447,1-1v-7h2c0.553,0,1-0.447,1-1c0-0.316-0.154-0.584-0.383-0.768  C18.184,8.34,12,3,12,3z"/></svg>
                        </a>
                    </li>
                    <li>
                        <a 
                            href="" 
                            aria-label="Je fais dons"
                            class="text-gray-600"
                        >
                        <svg class="w-6 h-6" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="hand-holding-heart" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><path fill="currentColor" d="M275.3 250.5c7 7.4 18.4 7.4 25.5 0l108.9-114.2c31.6-33.2 29.8-88.2-5.6-118.8-30.8-26.7-76.7-21.9-104.9 7.7L288 36.9l-11.1-11.6C248.7-4.4 202.8-9.2 172 17.5c-35.3 30.6-37.2 85.6-5.6 118.8l108.9 114.2zm290 77.6c-11.8-10.7-30.2-10-42.6 0L430.3 402c-11.3 9.1-25.4 14-40 14H272c-8.8 0-16-7.2-16-16s7.2-16 16-16h78.3c15.9 0 30.7-10.9 33.3-26.6 3.3-20-12.1-37.4-31.6-37.4H192c-27 0-53.1 9.3-74.1 26.3L71.4 384H16c-8.8 0-16 7.2-16 16v96c0 8.8 7.2 16 16 16h356.8c14.5 0 28.6-4.9 40-14L564 377c15.2-12.1 16.4-35.3 1.3-48.9z"></path></svg>
                        </a>
                    </li>
                    <li class="grid place-items-center" x-data="{ isOpen: false }">
                        <button 
                            aria-label="Créer"
                            class="text-gray-600"
                            @click="isOpen = !isOpen"
                        >
                            <svg aria-hidden="true" focusable="false" data-prefix="far" data-icon="plus-square" class="w-6 h-6" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path fill="currentColor" d="M352 240v32c0 6.6-5.4 12-12 12h-88v88c0 6.6-5.4 12-12 12h-32c-6.6 0-12-5.4-12-12v-88h-88c-6.6 0-12-5.4-12-12v-32c0-6.6 5.4-12 12-12h88v-88c0-6.6 5.4-12 12-12h32c6.6 0 12 5.4 12 12v88h88c6.6 0 12 5.4 12 12zm96-160v352c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V80c0-26.5 21.5-48 48-48h352c26.5 0 48 21.5 48 48zm-48 346V86c0-3.3-2.7-6-6-6H54c-3.3 0-6 2.7-6 6v340c0 3.3 2.7 6 6 6h340c3.3 0 6-2.7 6-6z"></path></svg>
                        </button>
                        <article 
                            class="xs_nav_dropdown_content flex flex-col fixed right-0 bg-white px-2 py-2 rounded-t-md border"
                            x-show="isOpen"
                            :aria-hidden="!isOpen"
                            :hidden="!isOpen"
                            @click.away="isOpen = false"
                        >
                            <h1 class="flex-shrink-0 text-lg font-bold text-gray-900 mb-2 px-2">Créer</h1>
                            <ul class="w-full h-full overflow-y-auto">
                                <li class="mb-1">
                                    <a href="" class="w-full block rounded p-2 flex items-start hover:bg-gray-200">
                                        <span class="w-8 h-8 rounded-full grid place-items-center flex-shrink-0 mr-2 bg-gray-400 text-gray-900">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" viewBox="0 0 24 24" fill="currentColor"><path transform="rotate(45.001 19.345 4.656)" d="M17.223 3.039H21.466V6.273H17.223z"></path><path d="M8 16L11 16 18.287 8.713 15.287 5.713 8 13z"></path><path d="M19,19H8.158c-0.026,0-0.053,0.01-0.079,0.01c-0.033,0-0.066-0.009-0.1-0.01H5V5h6.847l2-2H5C3.897,3,3,3.896,3,5v14 c0,1.104,0.897,2,2,2h14c1.104,0,2-0.896,2-2v-8.668l-2,2V19z"></path></svg>
                                        </span>
                                        <div>
                                            <p class="text-md text-gray-900 font-semibold">Publication</p>
                                            <p class="text-xs">Partagez une publication sur le fil d'actualité</p>
                                        </div>
                                    </a>
                                </li>
                                <li class="mb-1">
                                    <a href="" class="w-full block rounded p-2 flex items-start hover:bg-gray-200">
                                        <span class="w-8 h-8 rounded-full grid place-items-center flex-shrink-0 mr-2 bg-gray-400 text-gray-900">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" aria-hidden="true" focusable="false" role="img" viewBox="0 0 24 24" fill="currentColor"><path d="M20.664 3.478L8 8v7l.748.267-1.127 2.254c-.26.519-.281 1.123-.06 1.659.223.536.665.949 1.216 1.133l4.084 1.361c.205.068.416.101.624.101.741 0 1.451-.414 1.797-1.104l1.303-2.606 4.079 1.457c.65.233 1.336-.25 1.336-.941V4.419C22 3.728 21.314 3.245 20.664 3.478zM13.493 19.777L9.41 18.416l1.235-2.471 4.042 1.444L13.493 19.777zM4 15h2V8H4c-1.103 0-2 .897-2 2v3C2 14.103 2.897 15 4 15z"></path></svg>
                                        </span>
                                        <div>
                                            <p class="text-md text-gray-900 font-semibold">Témoignage</p>
                                            <p class="text-xs">Partagez votre témoignage pour édifier quelqu'un qui traverse votre situation</p>
                                        </div>
                                    </a>
                                </li><li class="mb-1">
                                    <a href="" class="w-full block rounded p-2 flex items-start hover:bg-gray-200">
                                        <span class="w-8 h-8 rounded-full grid place-items-center flex-shrink-0 mr-2 bg-gray-400 text-gray-900">
                                            <svg class="w-5 h-5" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="book-open" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><path fill="currentColor" d="M542.22 32.05c-54.8 3.11-163.72 14.43-230.96 55.59-4.64 2.84-7.27 7.89-7.27 13.17v363.87c0 11.55 12.63 18.85 23.28 13.49 69.18-34.82 169.23-44.32 218.7-46.92 16.89-.89 30.02-14.43 30.02-30.66V62.75c.01-17.71-15.35-31.74-33.77-30.7zM264.73 87.64C197.5 46.48 88.58 35.17 33.78 32.05 15.36 31.01 0 45.04 0 62.75V400.6c0 16.24 13.13 29.78 30.02 30.66 49.49 2.6 149.59 12.11 218.77 46.95 10.62 5.35 23.21-1.94 23.21-13.46V100.63c0-5.29-2.62-10.14-7.27-12.99z"></path></svg>
                                        </span>
                                        <div>
                                            <p class="text-md text-gray-900 font-semibold">Enseignement</p>
                                            <p class="text-xs">Partagez votre témoignage pour édifier quelqu'un qui traverse votre situation</p>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a href="" class="w-full block rounded p-2 flex items-start hover:bg-gray-200">
                                        <span class="w-8 h-8 rounded-full grid place-items-center flex-shrink-0 mr-2 bg-gray-400 text-gray-900">
                                            <svg class="w-5 h-5" aria-hidden="true" focusable="false" data-prefix="far" data-icon="calendar-alt" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path fill="currentColor" d="M148 288h-40c-6.6 0-12-5.4-12-12v-40c0-6.6 5.4-12 12-12h40c6.6 0 12 5.4 12 12v40c0 6.6-5.4 12-12 12zm108-12v-40c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v40c0 6.6 5.4 12 12 12h40c6.6 0 12-5.4 12-12zm96 0v-40c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v40c0 6.6 5.4 12 12 12h40c6.6 0 12-5.4 12-12zm-96 96v-40c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v40c0 6.6 5.4 12 12 12h40c6.6 0 12-5.4 12-12zm-96 0v-40c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v40c0 6.6 5.4 12 12 12h40c6.6 0 12-5.4 12-12zm192 0v-40c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v40c0 6.6 5.4 12 12 12h40c6.6 0 12-5.4 12-12zm96-260v352c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V112c0-26.5 21.5-48 48-48h48V12c0-6.6 5.4-12 12-12h40c6.6 0 12 5.4 12 12v52h128V12c0-6.6 5.4-12 12-12h40c6.6 0 12 5.4 12 12v52h48c26.5 0 48 21.5 48 48zm-48 346V160H48v298c0 3.3 2.7 6 6 6h340c3.3 0 6-2.7 6-6z"></path></svg>
                                        </span>
                                        <div>
                                            <p class="text-md text-gray-900 font-semibold">Evènement</p>
                                            <p class="text-xs">Partagez votre témoignage pour édifier quelqu'un qui traverse votre situation</p>
                                        </div>
                                    </a>
                                </li>
                            </ul>
                        </article>
                    </li>
                    <li>
                        <a 
                            href="" 
                            aria-label="Web Tv"
                            class="text-gray-600"
                        >
                            <svg class="w-6 h-6" aria-hidden="true" focusable="false" fill="currentColor" id="Layer_1" version="1.1" viewBox="0 0 50 50" role="img" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><rect fill="none" height="50" width="50"/><rect fill="none" height="30" stroke="currentColor" stroke-linecap="round" stroke-miterlimit="10" stroke-width="2" width="48" x="1" y="8"/><line fill="none" stroke="currentColor" stroke-linecap="round" stroke-miterlimit="10" stroke-width="2" x1="39" x2="11" y1="42" y2="42"/><path d="M31.977,23.049l-11.021-6.363c-0.197-0.113-0.441-0.113-0.637,0C20.121,16.799,20,17.009,20,17.236v12.729  c0,0.228,0.121,0.438,0.318,0.551c0.098,0.057,0.208,0.085,0.318,0.085c0.109,0,0.22-0.028,0.318-0.085l11.021-6.363  c0.197-0.114,0.318-0.324,0.318-0.552S32.174,23.163,31.977,23.049z"/></svg>
                        </a>
                    </li>
                    <li class="" x-data="{ isOpen: false }">
                        <button  
                            aria-label="Mon Compte"
                            class="w-8 h-8 grid place-items-center rounded-full border-2"
                            @click="isOpen = !isOpen"
                        >
                            <img 
                                src="/images/user/pexels-andrea-piacquadio-3907440.jpg" 
                                alt="photo de profil de Andrea Piacquadio" 
                                class="w-full h-full rounded-full object-center object-scale-down"
                            />
                        </button>
                        <article 
                            class="xs_nav_dropdown_content flex flex-col fixed right-0 bg-white px-2 py-2 rounded-t-md border"
                            x-show="isOpen"
                            :aria-hidden="!isOpen"
                            :hidden="!isOpen"
                            @click.away="isOpen = false"
                        >
                            <h1 class="flex-shrink-0 text-lg font-bold text-gray-900 mb-2 px-2">Mon Compte</h1>
                            <ul class="h-full overflow-y-auto">
                                <li class="mb-1">
                                    <a href="" class="w-full block rounded p-2 flex items-center hover:bg-gray-200">
                                        <span class="w-8 h-8 rounded-full grid place-items-center flex-shrink-0 mr-2 bg-gray-400 text-gray-900">
                                            <svg class="w-5 h-5" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="user" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path fill="currentColor" d="M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0 96 57.3 96 128s57.3 128 128 128zm89.6 32h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48v-41.6c0-74.2-60.2-134.4-134.4-134.4z"></path></svg>
                                        </span>
                                        <p class="text-md font-semibold text-gray-900">Mon profil</p>
                                    </a>
                                </li>
                                <li class="mb-1">
                                    <a href="" class="w-full block rounded p-2 flex items-center hover:bg-gray-200">
                                        <span class="w-8 h-8 rounded-full grid place-items-center flex-shrink-0 mr-2 bg-gray-400 text-gray-900">
                                            <svg class="w-5 h-5" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="user-edit" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512"><path fill="currentColor" d="M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0 96 57.3 96 128s57.3 128 128 128zm89.6 32h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h274.9c-2.4-6.8-3.4-14-2.6-21.3l6.8-60.9 1.2-11.1 7.9-7.9 77.3-77.3c-24.5-27.7-60-45.5-99.9-45.5zm45.3 145.3l-6.8 61c-1.1 10.2 7.5 18.8 17.6 17.6l60.9-6.8 137.9-137.9-71.7-71.7-137.9 137.8zM633 268.9L595.1 231c-9.3-9.3-24.5-9.3-33.8 0l-37.8 37.8-4.1 4.1 71.8 71.7 41.8-41.8c9.3-9.4 9.3-24.5 0-33.9z"></path></svg>
                                        </span>
                                        <p class="text-md font-semibold text-gray-900">Editer mon profil</p>
                                    </a>
                                </li>
                                <li class="mb-1">
                                    <a href="" class="w-full block rounded p-2 flex items-center hover:bg-gray-200">
                                        <span class="w-8 h-8 rounded-full grid place-items-center flex-shrink-0 mr-2 bg-gray-400 text-gray-900">
                                            <svg class="w-5 h-5" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="cross" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><path fill="currentColor" d="M352 128h-96V32c0-17.67-14.33-32-32-32h-64c-17.67 0-32 14.33-32 32v96H32c-17.67 0-32 14.33-32 32v64c0 17.67 14.33 32 32 32h96v224c0 17.67 14.33 32 32 32h64c17.67 0 32-14.33 32-32V256h96c17.67 0 32-14.33 32-32v-64c0-17.67-14.33-32-32-32z"></path></svg>
                                        </span>
                                        <p class="text-md font-semibold text-gray-900">J'accepte Jésus-Christ</p>
                                    </a>
                                </li>
                                <li class="mb-1">
                                    <a href="" class="w-full block rounded p-2 flex items-center hover:bg-gray-200">
                                        <span class="w-8 h-8 rounded-full grid place-items-center flex-shrink-0 mr-2 bg-gray-400 text-gray-900">
                                            <svg class="w-5 h-5" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="users-cog" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512"><path fill="currentColor" d="M610.5 341.3c2.6-14.1 2.6-28.5 0-42.6l25.8-14.9c3-1.7 4.3-5.2 3.3-8.5-6.7-21.6-18.2-41.2-33.2-57.4-2.3-2.5-6-3.1-9-1.4l-25.8 14.9c-10.9-9.3-23.4-16.5-36.9-21.3v-29.8c0-3.4-2.4-6.4-5.7-7.1-22.3-5-45-4.8-66.2 0-3.3.7-5.7 3.7-5.7 7.1v29.8c-13.5 4.8-26 12-36.9 21.3l-25.8-14.9c-2.9-1.7-6.7-1.1-9 1.4-15 16.2-26.5 35.8-33.2 57.4-1 3.3.4 6.8 3.3 8.5l25.8 14.9c-2.6 14.1-2.6 28.5 0 42.6l-25.8 14.9c-3 1.7-4.3 5.2-3.3 8.5 6.7 21.6 18.2 41.1 33.2 57.4 2.3 2.5 6 3.1 9 1.4l25.8-14.9c10.9 9.3 23.4 16.5 36.9 21.3v29.8c0 3.4 2.4 6.4 5.7 7.1 22.3 5 45 4.8 66.2 0 3.3-.7 5.7-3.7 5.7-7.1v-29.8c13.5-4.8 26-12 36.9-21.3l25.8 14.9c2.9 1.7 6.7 1.1 9-1.4 15-16.2 26.5-35.8 33.2-57.4 1-3.3-.4-6.8-3.3-8.5l-25.8-14.9zM496 368.5c-26.8 0-48.5-21.8-48.5-48.5s21.8-48.5 48.5-48.5 48.5 21.8 48.5 48.5-21.7 48.5-48.5 48.5zM96 224c35.3 0 64-28.7 64-64s-28.7-64-64-64-64 28.7-64 64 28.7 64 64 64zm224 32c1.9 0 3.7-.5 5.6-.6 8.3-21.7 20.5-42.1 36.3-59.2 7.4-8 17.9-12.6 28.9-12.6 6.9 0 13.7 1.8 19.6 5.3l7.9 4.6c.8-.5 1.6-.9 2.4-1.4 7-14.6 11.2-30.8 11.2-48 0-61.9-50.1-112-112-112S208 82.1 208 144c0 61.9 50.1 112 112 112zm105.2 194.5c-2.3-1.2-4.6-2.6-6.8-3.9-8.2 4.8-15.3 9.8-27.5 9.8-10.9 0-21.4-4.6-28.9-12.6-18.3-19.8-32.3-43.9-40.2-69.6-10.7-34.5 24.9-49.7 25.8-50.3-.1-2.6-.1-5.2 0-7.8l-7.9-4.6c-3.8-2.2-7-5-9.8-8.1-3.3.2-6.5.6-9.8.6-24.6 0-47.6-6-68.5-16h-8.3C179.6 288 128 339.6 128 403.2V432c0 26.5 21.5 48 48 48h255.4c-3.7-6-6.2-12.8-6.2-20.3v-9.2zM173.1 274.6C161.5 263.1 145.6 256 128 256H64c-35.3 0-64 28.7-64 64v32c0 17.7 14.3 32 32 32h65.9c6.3-47.4 34.9-87.3 75.2-109.4z"></path></svg>
                                        </span>
                                        <p class="text-md font-semibold text-gray-900">Administration</p>
                                    </a>
                                </li>
                                <li class="border-t-2 pt-1">
                                    <a href="" class="w-full block rounded p-2 flex items-center hover:bg-gray-200">
                                        <span class="w-8 h-8 rounded-full grid place-items-center flex-shrink-0 mr-2 bg-gray-400 text-gray-900">
                                            <svg class="w-5 h-5" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" role="img" width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M16 13L16 11 7 11 7 8 2 12 7 16 7 13z"></path><path d="M20,3h-9C9.897,3,9,3.897,9,5v4h2V5h9v14h-9v-4H9v4c0,1.103,0.897,2,2,2h9c1.103,0,2-0.897,2-2V5C22,3.897,21.103,3,20,3z"></path></svg>
                                        </span>
                                        <p class="text-md text-gray-900 font-semibold">Déconnexion</p>
                                    </a>
                                </li>
                            </ul>
                        </article>
                    </li>
                </ul>
            </nav>
        </section>
    </template>
</header>
   
            

    

<?php /**PATH C:\Web\salut\resources\views/laptop-headernav.blade.php ENDPATH**/ ?>