

 <?php $__env->startSection('content'); ?>
 <div>
   <h1 class="text-center">Gestion statut publication</h1>
   <div class="max-w-screen-md mx-auto px-3 py-5 mb-3 shadow-sm hover:shadow-md rounded border-2 border-gray-300">
            <div class="mb-8">
                <a href="<?php echo e(route('profil.index',$post->user)); ?>" class="no-underline hover:no-underline focus:outline-none font-bold uppercase"><?php echo e($post->user->name.' '.$post->user->firstname); ?>

                </a><i> publié le <?php echo e($post->created_at); ?></i>
                 <img src="<?php echo e($post->user->profile_photo_url); ?>" title="Photo de profil de <?php echo e($post->user->firstname); ?>" class="h-20 w-20">
            </div>
           <div>
           <p class="text-base font-semibold break-all"><?=replace_links(nl2br($post->message))?>
           </p>
             <?php if($post->image): ?>
                 <div class="mb-8">
                  <a href="<?php echo e(asset('storage/'.$post->image)); ?>"><img src="<?php echo e(asset('storage/'.$post->image)); ?>"></a>
                 </div>
                <?php endif; ?> 

               
               <h5><span class="badge badge-<?php echo e($post->status == 'INACTIF' ? 'danger' : 'success'); ?>"><?php echo e($post->status); ?></span></h5>
            </div>
            <div>
            <div>
            <form method="POST" action="<?php echo e(route('admin.update.posts',$post)); ?>">
             <?php echo csrf_field(); ?>
             <?php echo method_field('PATCH'); ?>
              <a href="<?php echo e(route('admin.index.posts')); ?>" class="btn btn-primary"><i class="fa fa-arrow-left" aria-hidden="true"></i> Retour</a>
             <button type="submit" class="btn btn-success"><i class="fa fa-check-square-o" aria-hidden="true"></i> Appouver</button>
          </form>
      </div>
      </div>
   </div>
 </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master',['title'=>'Statut-publication'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web\salut\resources\views/admin/posts/edit.blade.php ENDPATH**/ ?>