

<?php $__env->startSection('content'); ?>

  <main class="px-10 pt-10 pb-6">
    <h1 class="text-xl font-extrabold text-gray-700 mb-10">Evènements (<span class="text-red-500"><?php echo e($totals->count()); ?></span>)</h1>

    <section class="bg-white p-4 rounded-md">
      <?php if($posts->count()>0): ?>

        <!-- TABLEAU -->
        <div class="">
          <table class="w-full table" id="table">
            <thead class="bg-gray-200 text-gray-800">
              <tr>
                <th scope="col">#</th>
                <th scope="col">Nom et prenom.s utilisateur</th>
                <th scope="col">Date de publication</th>
                <th scope="col"></th>
              </tr>
            </thead>

            <tbody>
              <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr class="text-sm text-gray-600">
                  <td><?php echo e($post->id); ?></td>
                  <td>
                    <a href="<?php echo e(route('profil.index',$post->user)); ?>" class="text-gray-600 hover:text-gray-600 hover:underline"><?php echo e($post->user->name.' '.$post->user->firstname); ?></a>
                  </td>
                  <td><?php echo e($post->created_at); ?></td>
                  <td>
                    <a href="<?php echo e(route('admin.shows.evenements',$post->user)); ?>" class="text-xs bg-green-500 px-2 py-1 rounded-sm font-light text-white">Voir évènement.s</a>
                  </td>
                </tr>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
         <div class="mt-4">
          <?php echo e($posts->links()); ?>

       </div>
      <?php else: ?>

        <div class="alert alert-primary alert-dismissible fade show" role="alert">
          <strong>Aucun évènement disponible pour l'instant!</strong>
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>

      <?php endif; ?>
    </section>
  </main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master',['title'=>'Evenements'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web\salut\resources\views/admin/events/index.blade.php ENDPATH**/ ?>