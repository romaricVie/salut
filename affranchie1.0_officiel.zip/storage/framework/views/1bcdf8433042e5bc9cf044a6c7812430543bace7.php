

 <?php $__env->startSection('content'); ?>
  
    <div>
         <div class="max-w-screen-md mx-auto px-3 py-5 mb-3 shadow-sm hover:shadow-md rounded border-2 border-gray-300">
          <span class="font-bold uppercase no-underline "><?php echo e($donation->name.' '.$donation->firstname); ?></span>
                <i>Enrégistré le <?php echo e($donation->created_at); ?></i>
                <div>
                    <p><?php echo e($donation->description); ?></p>
              </div>
             <div class="mb-8">
               <a href="<?php echo e(asset('storage/'.$donation->images)); ?>"><img src="<?php echo e(asset('storage/'.$donation->images)); ?>"></a>
             </div>
               <div>
               <h5><span class="badge badge-danger"><?php echo e($donation->status); ?></span></h5>
               <a href="<?php echo e(route('admin.donation.edit',$donation)); ?>" class="btn btn-primary"><i class="fa fa-edit"></i> Editer</a>
                <form 
                  action="<?php echo e(route('admin.donation.delete',$donation)); ?>"
                  method="POST"
                  class="d-inline"
                  onsubmit ="return confirm('Etre vous sur de vouloir supprimer cet don?');"
                  >
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <a href=""><button class="btn btn-warning"><i class="fa fa-trash"></i> Supprimer Don</button></a>
              </form>
      </div>
         </div>
   </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master',['title'=>'Dons-invites'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web\salut\resources\views/admin/dons-invites/show.blade.php ENDPATH**/ ?>