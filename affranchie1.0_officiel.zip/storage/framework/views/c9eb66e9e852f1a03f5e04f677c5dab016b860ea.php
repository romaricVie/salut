 <?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GuestLayout::class, []); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('title'); ?> Don en finance <?php $__env->endSlot(); ?>

    <header
      x-data="{ atTop: true, screenWidth: window.outerWidth }" 
      class="w-full fixed top-0 left-0 sm:bg-transparent sm:shadow-none"
      :class="{ 'bg-gray-100 sm:bg-red-800 shadow-md' : (!atTop) }"
      @scroll.window="atTop = (window.pageYOffset > 20) ? false : true"
      @resize.window="screenWidth = window.outerWidth"
    >
      <?php echo $__env->make('partials/_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </header>

    <main class="w-full min-h-screen pt-20 px-3 text-gray-600 bg-cover sm:px-10 sm:pt-40 pb-8 sm:px-8">
      <article class="max-w-screen-md mx-auto text-lg space-y-6">
        <h1 class="text-center text-3xl font-bold text-gray-900">Don en finance</h1>

        <section>
          <h2 class="text-center text-lg font-semibold text-gray-900 mb-4">Comptes Mobile Money</h2>
          <article class="flex items-center justify-center">
            <img src="<?php echo e(asset('/images/om.png')); ?>" alt="Numéro de compte Orange Money" class="w-24 h-auto">
            <img src="<?php echo e(asset('/images/flooz.png')); ?>" alt="Numéro de compte Flooz" class="w-24 h-auto mx-4">
            <img src="<?php echo e(asset('/images/momo.png')); ?>" alt="Numéro de compte MTN Mobile Money" class="w-24 h-auto">
          </article>
        </section>

        <section>
          <h2 class="text-center text-lg font-semibold text-gray-900">Compte bancaire</h2>
        </section>
      </article>
    </main>
      
 <?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH C:\Web\salut\resources\views/dons/finance-guest.blade.php ENDPATH**/ ?>