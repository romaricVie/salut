 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title'); ?> Membres de la Communauté <?php $__env->endSlot(); ?>

   <!--Members-->
   <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('members')->html();
} elseif ($_instance->childHasBeenRendered('q9tSWzm')) {
    $componentId = $_instance->getRenderedChildComponentId('q9tSWzm');
    $componentTag = $_instance->getRenderedChildComponentTagName('q9tSWzm');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('q9tSWzm');
} else {
    $response = \Livewire\Livewire::mount('members');
    $html = $response->html();
    $_instance->logRenderedChild('q9tSWzm', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <!-- SCRIPT -->
    <script type="text/javascript">
        function placeSubmenu() {
            return {
                atTop: false,
                setAtTop: function() {
                    // Pour les écrans >= 768 
                    if( window.outerWidth >= 768 && window.outerWidth < 1024 ) {
                        this.atTop = (window.pageYOffset > 80) ? true : false
                    }
                    // Pour les écrans < 768
                    if( window.outerWidth < 768 ) {
                        this.atTop = (window.pageYOffset > 60) ? true : false
                    }
                }
            }
        }
    </script>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH C:\Web\salut\resources\views/membres/index.blade.php ENDPATH**/ ?>