

<?php $__env->startSection('content'); ?>
<main class="px-10 pt-10 pb-6">
   <h1 class="text-xl font-extrabold text-gray-700 mb-10">Edition de sujet</h1>
    <section class="bg-white p-4 rounded-md">
        <div>
          <form method="POST" action="<?php echo e(route('admin.update.intercessions',$intercession)); ?>">
               <?php echo csrf_field(); ?>
               <?php echo method_field('PATCH'); ?>
               <?php echo $__env->make('admin/intercessions/partial/_form',['text'=>'Modifier les sujets'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </form>
      </div>
    </section>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master',['title'=>'Editer-sujet'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web\salut\resources\views/admin/intercessions/edit.blade.php ENDPATH**/ ?>