

 <?php $__env->startSection('content'); ?>
  <?php if($donations->count()>0): ?>
  <h1 class="text-center">(<span style="color: red"><?php echo e($donations->count()); ?></span>) Dons </h1>
  <?php $__currentLoopData = $donations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div>
       <div class="max-w-screen-md mx-auto px-3 py-5 mb-3 shadow-sm hover:shadow-md rounded border-2 border-gray-300">
          <div class="mb-8">
              <span class="font-bold uppercase no-underline "><?php echo e($donation->name.' '.$donation->firstname); ?></span>
                    </a><i>Enrégistré le <?php echo e($donation->created_at); ?></i>
                     <p class="text-center mt-5">
                       <a href="<?php echo e(route('admin.donation.show',$donation)); ?>">
                        <button class="btn btn-success"><i class="fa fa-eye"></i> Voir détail</button>
                      </a>
                     </p> 
               </div>      
          </div>
   </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 
<?php else: ?>
 <div class="alert alert-primary alert-dismissible fade show" role="alert">
  <strong>Aucun don disponible pour l'instant!</strong>
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master',['title'=>'Dons-invites'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web\salut\resources\views/admin/dons-invites/index.blade.php ENDPATH**/ ?>