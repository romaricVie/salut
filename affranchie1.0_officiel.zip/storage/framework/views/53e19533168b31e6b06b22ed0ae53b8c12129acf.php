 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('title'); ?> 
           messages en attente
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
             Messages en attente d'approbation
        </h2>
     <?php $__env->endSlot(); ?>
    <div class="max-w-screen-md mx-auto px-3 py-5 mb-3 shadow-sm hover:shadow-md rounded border-2 border-gray-300 bg-white">
       <form method="POST" action="<?php echo e(route('post.update', $post)); ?>" enctype="multipart/form-data" id="image-upload-preview">
                 <?php echo csrf_field(); ?>
                 <?php echo method_field('PATCH'); ?>
         <div class="mt-3">
          <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.validation-errors','data' => ['class' => 'mb-4']]); ?>
<?php $component->withName('jet-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-4']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
           <div class="space-x-2">
             <div class="inline-block">
               <div class="">
                  <textarea class="resize border rounded-md bg-white border border-red-500 focus:border-blue-500 placeholder-black py-2 px-2" cols="30" rows="8" name="message" placeholder="j'évangélise..."><?php echo e(old('message')? old('message') : $post->message); ?></textarea>
               </div>
             </div>

              <div  x-data="{ open: false }" class="inline-block">
                <input type="file" class="hidden" x-ref="fileInput" id="image" name="image">
                     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.secondary-button','data' => ['class' => 'mt-2 mr-2','type' => 'button','xOn:click.prevent' => '$refs.fileInput.click()']]); ?>
<?php $component->withName('jet-secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mt-2 mr-2','type' => 'button','x-on:click.prevent' => '$refs.fileInput.click()']); ?>
                       <svg class="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                    <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

             </div> 
             <div class="inline-block m-2">
                <img id="preview-image" src="#" alt="" style="max-height: 200px; max-width: 200px;">
           </div>
             <?php if($post->image): ?>
                 <div class="mb-8 mt-5">
                   <a href="<?php echo e(asset('storage/'.$post->image)); ?>"><img src="<?php echo e(asset('storage/'.$post->image)); ?>"></a>
                 </div>
              <?php endif; ?> 
           </div>

       <div>
         <a href="<?php echo e(route('post.shows')); ?>" class="inline-flex items-center bg-blue-500 rounded py-3 px-6 mt-2 border-gray-300 rounded-md font-semibold text-md text-white  focus:outline-none">Retour</a>
          <button type="submit" class="inline-flex items-center bg-blue-500 rounded py-3 px-6 mt-2 border-gray-300 rounded-md font-semibold text-md text-white  focus:outline-none">Modifier message</button>
       </div>
  </div>
 </form> 
</div>

  <!--Upload Image with Preview-->
  
   <script type="text/javascript">
    $('#image').change(function(){
           
    let reader = new FileReader();

    reader.onload = (e) => { 

      $('#preview-image').attr('src', e.target.result); 
    }

    reader.readAsDataURL(this.files[0]); 
  
   });
  </script>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 




<?php /**PATH C:\Web\salut\resources\views/posts/edit.blade.php ENDPATH**/ ?>