 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('title'); ?> 
          Aide
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Nous avons besoin d\'aide')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <div class="text-center">
  	     <p class="text-xl text-gray-700 font-bold mt-4">Pour le bon fonctionnement de cette plateforme nous avons besoin:</p>
    </div>
     <div class="flex flex-row justify-center">
           <div class="px-2 py-2 w-64 h-auto m-2 rounded border border-green-600 bg-green-200">
              <p class="text-xl font-semibold">Besoins matériels</p>
			     <ul class="list-disc list-inside">
					  <li>Local</li>
					  <li>Odinateurs</li>
					  <li>Equipements audios visuelles</li>
					  <li>Abonnement Internet</li>
					  <li>Voiture</li>  
			     </ul>
          </div>
          <div class="px-2 py-2 w-64 h-auto m-2 rounded border border-green-600 bg-green-200">
             <p class="text-xl font-semibold">Besoins humains</p>
		     <ul class="list-disc list-inside">
				  <li>Développeurs d'application web et mobile</li>
				  <li>Administrateurs</li>
				  <li>Moderateurs</li>  
		      </ul>  
          </div>
      </div> 
      <div class="max-w-screen-md mx-auto p-4 mt-2 shadow-sm hover:shadow-md rounded border-2 border-4 bg-white">
        <p class="mb-5 text-lg">Pour toutes personnes souhaitant nous aider, veuillez nous contacter par email à l'adresse:  <a href="mailto:administration@affranchie.com">administration@affranchie.com</a>
          </p>  
       </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH C:\Web\salut\resources\views/pages/help.blade.php ENDPATH**/ ?>