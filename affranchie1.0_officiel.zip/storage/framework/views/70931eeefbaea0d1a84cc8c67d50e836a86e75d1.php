

 <?php $__env->startSection('content'); ?>
<h1>Show Postes </h1>

<div class="py-12">
     <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
            <a href="<?php echo e(route('profil.index',$post->user)); ?>"><span><?php echo e($post->user->name); ?></span></a>
            <?php if($post->image): ?>
               <img src="<?php echo e(asset('storage/'.$post-> image)); ?>" style="width:50px; height: 50px;">
            <?php endif; ?>
            <p>
	           <?= nl2br($post->message)?>
	         </p>
	            <i><?php echo e($post->created_at); ?></i><br>
               <h5><span class="badge badge-danger"><?php echo e($post->status); ?></span></h5>
               <a href="<?php echo e(route('admin.edit.posts',$post)); ?>" class="btn btn-success">Editer</a>

               
                <form 
                     action="<?php echo e(route('admin.destroy.posts',$post)); ?>"
                      method="POST"
                      class="d-inline"
                      onsubmit ="return confirm('Etre vous sur de vouloir supprimer cet poste?');"
                          >
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <a href=""><button class="btn btn-warning"><i class="fa fa-trash"></i> Supprimer</button></a>
                       </form>
         </div>
      </div>
   </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web\salut\resources\views/admin/posts/show.blade.php ENDPATH**/ ?>