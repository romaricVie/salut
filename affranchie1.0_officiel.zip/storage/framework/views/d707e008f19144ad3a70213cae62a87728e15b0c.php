<div>
  <form wire:submit.prevent="save" enctype="multipart/form-data">

         <?php echo csrf_field(); ?>  
        <div class="row">
          <div class="col-md-6">
            <!--Tel field-->
            <div class="form-group">
               <label for="tel" class="col-form-label"><?php echo e(__('Numero mobile')); ?></label>
               <input id="tel" type="text" class="form-control <?php $__errorArgs = ['tel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tel" value="<?php echo e(old('tel') ?? old('tel')); ?>"   autocomplete="tel" autofocus wire:model="tel">
                    <?php $__errorArgs = ['tel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
               </div>  
          </div>
          <div class="col-md-6">
             <!--name product field-->
            <div class="form-group">
               <label for="nom" class="col-form-label"><?php echo e(__('Nom du produit *')); ?></label>
               <input id="nom" type="text" class="form-control <?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nom" value="<?php echo e(old('nom') ?? old('nom')); ?>"   autocomplete="nom" autofocus wire:model="nom">
                    <?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
               </div>  
          </div>
          <div class="col-md-12">
            <!--Description field-->
             <div class="form-group">
                <label for="description" class="col-form-label"><?php echo e(__('Description du don *')); ?></label>
                <textarea id="description" rows ="10" cols="10" type="text" class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="description" autocomplete="description" wire:model="description"></textarea>

                     <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div> 
          </div>
          <div class="col-md-6">
             <!--Montant field-->
            <div class="form-group">
               <label for="montant" class="col-form-label"><?php echo e(__('Montant(estimation du don )')); ?></label>
               <input id="montant" type="text" class="form-control <?php $__errorArgs = ['montant'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="montant" value="<?php echo e(old('montant') ?? old('montant')); ?>"   autocomplete="montant" autofocus wire:model="montant">
                    <?php $__errorArgs = ['montant'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
               </div>  
          </div>
          
             <!--Images field-->
            <div class="col-md-12">
                 <div class="form-group">			             
                 	<div wire:loading wire:target="images">Chargement...</div>
                <div
                x-data="{ isUploading: false, progress: 0 }"
						    x-on:livewire-upload-start="isUploading = true"
						    x-on:livewire-upload-finish="isUploading = false"
						    x-on:livewire-upload-error="isUploading = false"
						    x-on:livewire-upload-progress="progress = $event.detail.progress"
                            >

                          	<!--Input file-->
                          
                           <input x-ref="fileInput" type="file" multiple wire:model="images" class="hidden">
                            <div @click="$refs.fileInput.click()"><i class="fa fa-picture-o fa-4x" aria-hidden="true"></i>Choisir image(s)
                            <?php $__errorArgs = ['images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          
                            </div>
                          	<!--Progress bar-->
                          	<div x-show="isUploading">
                                <progress max="100" x-bind:value="progress"></progress>
                            </div>
                          </div>

                   <?php if($images): ?>
                   	<?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex justify-center" wire:key="<?php echo e($loop->index); ?>">
                     	  <i class="fa fa-times-circle text-gray-700 text-2xl float-right cursor-pointer " wire:click="remove(<?php echo e($loop->index); ?>)"></i>
                     	 <img src="<?php echo e($image->temporaryUrl()); ?>" width="250">
                     </div>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     <?php endif; ?>
                  </div>
                </div>                
      
              <!-- Type don radio-->
            <div class="col-md-12">
              <div class="form-group">
                <label>Type du don</label>
                 <div class="form-check">
                   <input class="form-check-input" type="radio" value="donVivre" name="type" id="type" wire:model="type">
                   <label class="form-check-label" for="type">Don en vivre(alimentaires, sac de riz, huile etc…) </label>  
                 </div>
                  <div class="form-check">
                   <input class="form-check-input" type="radio" value="donNonVivre" name="type" id="type1" wire:model="type">
                   
                   <label class="form-check-label" for="type1">Don non vivre (tenue vestimentaires, instrument de musique etc…)</label>  
                 </div>
                  <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div> 
        </div>
           <!-- Etat du  field radio-->
           <div class="col-md-12">
               <div class="form-group">
                <span>Etat du don</span> 
                 <div class="form-check">
                   <input class="form-check-input" type="radio" value="Neuf" name="etat" id="radio1" wire:model="etat">
                   <label class="form-check-label" for="radio1">Neuf</label>  
                 </div>

                 <div class="form-check">
                   <input class="form-check-input" type="radio" value="Occassion" name="etat" id="radio2" wire:model="etat">
                 
                   <label class="form-check-label" for="radio2">Occassion</label>  
                 </div>
                  <div class="form-check">
                   <input class="form-check-input" type="radio" value="OccassionNeuf" name="etat" id="radio3" wire:model="etat">
                   <label class="form-check-label" for="radio3">Occassion remis à neuf</label>  
                 </div>
                  <div class="form-check">
                   <input class="form-check-input" type="radio" value="bonEtat" name="etat" id="radio4" wire:model="etat">
                   <label class="form-check-label" for="radio4">Bon etat</label>  
                 </div>
                  <?php $__errorArgs = ['etat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
               </div>  
           </div>
            <div class="col-md-12">
               <!--Point de presence field-->
               <div class="form-group">
                 <label for="pointPresence">Choisir un point de présence</label> 
                  <select class="custom-select" id="pointPresence" name="recuperation" wire:model="recuperation">
                             <option  value="">Choisir Jour...</option>
                             <?php $__currentLoopData = $villes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ville): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($ville->name); ?>"><?php echo e($ville->name); ?></option>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  <?php $__errorArgs = ['recuperation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                   </div>          
               </div>  
         <div class="col-md-12">
            <button type="submit" class="btn btn-primary"><?php echo e(('Donation')); ?></button>
        </div>
     </div>  
   </form>
</div>
<?php /**PATH C:\Web\salut\resources\views/livewire/don-nature.blade.php ENDPATH**/ ?>