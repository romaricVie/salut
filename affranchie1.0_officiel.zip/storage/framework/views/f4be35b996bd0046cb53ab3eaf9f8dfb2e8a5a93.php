 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title'); ?> Pages communautes <?php $__env->endSlot(); ?>

   <!--Members-->
   <div>
     <section 
        x-data="placeSubmenu()"
        class="pt-2 pb-4 px-1 sm:pt-4 sm:pb-0 sm:px-4"
        id="members" 
    >
        <section 
            class="max-w-screen-xl mx-auto rounded p-2 bg-white flex items-center justify-between md:p-3"
            @scroll.window="setAtTop"
            @resize.window="setAtTop"
            :class="{
                      'max-w-full fixed at__top px-1 sm:px-3' : atTop,
                      'xl__at__top shadow' : (window.outerWidth >= 1280  && atTop),
                      'lg__at__top shadow' : (window.outerWidth >= 1024 && 1280 > window.outerWidth && atTop),
                      'sm__at__top shadow' : (window.outerWidth >= 640 && 1024 > window.outerWidth && atTop),
                      'xs__at__top shadow' : (640 > window.outerWidth && atTop)
                    }"
        >
            <h1 class="text-sm text-red-700 font-semibold ml-1 sm:ml-0 sm:text-base lg:text-lg">Pages <span class="hidden sm:inline">de la communauté</span> 
                <a href="<?php echo e(route('communaute.create')); ?>"> créer page</a>
            </h1>
          
        </section>

        <section class="max-w-screen-xl mx-auto grid grid-cols-1 gap-1 pt-6 pb-1 mt-2 sm:grid-cols-2 sm:gap-3 md:px-4 md:grid-cols-3 xl:grid-cols-4" :class="{ 'mt-20' : atTop }">

            <?php $__currentLoopData = $communautes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $communaute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white p-2 rounded shadow hover:bg-gray-100 sm:p-3">
                    <a 
                        href="<?php echo e(route('communaute.show', $communaute)); ?>"
                        class="w-full flex items-center sm:block"
                    >
                        <img 
                            src="<?php echo e(asset('storage/'.$communaute->image)); ?>" 
                            aria-label="Image  de <?php echo e($communaute->name); ?>" 
                            class="w-10 h-10 mr-2 flex-shrink-0 rounded-full object-center object-cover sm:w-16 sm:h-16 sm:mx-auto sm:rounded-full sm:mb-2 md:w-20 md:h-20"
                        />
                        <div class="w-full text-gray-800 truncate sm:text-center">
                            <h3 class="text-sm font-bold lg:text-base truncate"><?php echo e($communaute->name); ?></h3>
                            <h4 class="text-xs font-semibold lg:text-sm">Créée depuis le <?php echo e($communaute->start_at); ?></h4>
                        </div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </section>
        <div>
            <?php echo e($communautes->links()); ?>

        </div>
    </section>


</div>


    <!-- SCRIPT -->
    <script type="text/javascript">
        function placeSubmenu() {
            return {
                atTop: false,
                setAtTop: function() {
                    // Pour les écrans >= 768 
                    if( window.outerWidth >= 768 && window.outerWidth < 1024 ) {
                        this.atTop = (window.pageYOffset > 80) ? true : false
                    }
                    // Pour les écrans < 768
                    if( window.outerWidth < 768 ) {
                        this.atTop = (window.pageYOffset > 60) ? true : false
                    }
                }
            }
        }
    </script>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH C:\Web\salut\resources\views/Communautes/index.blade.php ENDPATH**/ ?>