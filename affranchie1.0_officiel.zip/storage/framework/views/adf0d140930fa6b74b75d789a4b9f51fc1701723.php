 <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
     
        <title><?php echo e(page_title($title ?? '')); ?></title>
        <link rel="icon" type="image/jpg" href="<?php echo e(asset('/images/logo.jpg')); ?>">
        <!-- Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@200;300;400;600;700&display=swap">

        <!-- Styles -->
        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/assets/boots/css/bootstrap.min.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/assets/css/admin.css')); ?>">

        <!-- Scripts -->
        <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.7.0/dist/alpine.js" defer></script>
    <?php echo \Livewire\Livewire::styles(); ?>

</head>
<?php /**PATH C:\Web\salut\resources\views/template/partials/_header.blade.php ENDPATH**/ ?>