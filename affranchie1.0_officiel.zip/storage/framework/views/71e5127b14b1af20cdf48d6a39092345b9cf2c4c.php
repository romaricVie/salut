<footer class="py-2 px-3 md:pr-0 lg:pl-20">
    <div class="flex flex-col md:flex-row items-center justify-center text-sm md:justify-start">
      <div>
       <a href="<?php echo e(route('dashboard')); ?>">Accueil</a> <a href="" class="mx-1">Facebook</a> <a href="" class="mx-1">Twitter</a> <a href="" class="mx-1">Youtube</a>
      </div>
      <p class="md:ml-3"><img src="<?php echo e(asset('/images/logo-texte.svg')); ?>" alt="logo affranchie" class="w-auto h-10 inline mr-2"> &copy; 2021 - Tous droits réservés</p>
    </div>
  </footer><?php /**PATH C:\Web\salut\resources\views/partials/_footerAuth.blade.php ENDPATH**/ ?>