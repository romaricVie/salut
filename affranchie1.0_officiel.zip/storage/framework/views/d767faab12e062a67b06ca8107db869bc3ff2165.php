

<?php $__env->startSection('content'); ?>
<main class="px-10 pt-10 pb-6">
  <h1 class="text-xl font-extrabold text-gray-700 mb-10">Edition de verset</h1>
  <section class="bg-white p-4 rounded-md">
          <form method="POST" action="<?php echo e(route('admin.update.versets',$verset)); ?>">
               <?php echo csrf_field(); ?>
               <?php echo method_field('PATCH'); ?>
               <?php echo $__env->make('admin/verset/partial/_form',['text'=>'Changer Verset'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </form>
    </section>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master',['title'=>'Edition-verset'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web\salut\resources\views/admin/verset/edit.blade.php ENDPATH**/ ?>