 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
	 <?php $__env->slot('title'); ?> Accueil <?php $__env->endSlot(); ?>

    <section class="w-full flex items-center py-4 px-0 flex-col-reverse sm:px-2 md:flex-row md:items-start">
        
        <section class="w-full text-gray-700">
            <!-- Verset du jour -->
          <article class="w-full bg-white mx-auto py-2 overflow-hidden border-b-2 border-gray-300 sm:mb-2 sm:border-none sm:shadow sm:max-w-xl sm:rounded-md relative">

          <?php if(isset($verset)): ?>
            <figure class="px-3 text-sm sm:text-base font-semibold text-gray-600">
              <p class="font-bold">Verset du jour:</p>
              <blockquote>
                <p><?=nl2br($verset->text)?> <cite class="ml-2 text-sm font-medium"><?php echo e($verset->book.' '.$verset->chapter.':'.$verset->verse); ?></cite></p>
              </blockquote>
            </figure>
          <?php else: ?>
            <p class="px-3 text-sm sm:text-base font-semibold text-gray-600">Pas de verset disponible !</p>
          <?php endif; ?>
        </article>
        <!-- Post's section -->
        <?php if($posts->count() >0): ?>
              <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('like-post', ['post' => $post])->html();
} elseif ($_instance->childHasBeenRendered('V61mfMj')) {
    $componentId = $_instance->getRenderedChildComponentId('V61mfMj');
    $componentTag = $_instance->getRenderedChildComponentTagName('V61mfMj');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('V61mfMj');
} else {
    $response = \Livewire\Livewire::mount('like-post', ['post' => $post]);
    $html = $response->html();
    $_instance->logRenderedChild('V61mfMj', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php else: ?>
           <p class="text-sm sm:text-base font-semibold text-gray-600">Aucun post disponible pour l'instant!</p>
          <?php endif; ?>
        </section>

        <!-- Aside Content -->
        <aside
           id="addingPost"
           class="w-full max-w-xl mb-4 flex-shrink-0 md:sticky md:w-auto md:max-w-auto md:mb-0 md:ml-2 xl:ml-0"
        >
            <form method="POST" action="<?php echo e(route('post.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?> 
                <?php echo $__env->make('partials/_form',['textButton' => 'Publier'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </form>
        </aside>
    </section>
    
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH C:\Web\salut\resources\views/dashboard.blade.php ENDPATH**/ ?>