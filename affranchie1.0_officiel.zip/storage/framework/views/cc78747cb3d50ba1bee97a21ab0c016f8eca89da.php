<div>
   <div>
   <div>
     
       <div class="row">
            <form wire:submit.prevent="store">
              <?php echo csrf_field(); ?>     
             <div class="col-md-12">
                    <div class="form-group">
                      <input type="file" multiple wire:model="images" placeholder="Choose image" id="image" class="form-control">
                    </div>
                    <?php $__errorArgs = ['images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                  
                <div class="col-md-12 mb-2">
                	<?php if($images): ?>
                    <img src="<?php echo e($image->temporaryUrl()); ?>" style="width: 100px; height:100px">
                    <?php endif; ?>
                </div>
                  
                <div class="col-md-12">
                    <button type="submit" class="btn btn-primary">Soumettre</button>
                </div>
            </div>     
        </form>
    </div>
</div>

<!--Upload Image with Preview-->

<!-- <script type="text/javascript">
    $('#image').change(function(){
           
    let reader = new FileReader();

    reader.onload = (e) => { 

      $('#preview-image').attr('src', e.target.result); 
    }

    reader.readAsDataURL(this.files[0]); 
  
   });
  </script> -->
</div>
<?php /**PATH C:\Web\salut\resources\views/livewire/test.blade.php ENDPATH**/ ?>