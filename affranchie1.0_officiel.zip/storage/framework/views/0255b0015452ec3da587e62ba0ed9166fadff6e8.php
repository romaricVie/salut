<div>
  <form wire:submit.prevent="save" enctype="multipart/form-data">

         <?php echo csrf_field(); ?>  
        <div class="row">
         
          <div class="col-md-12">
            <!--Description field-->
             <div class="form-group">
                <textarea id="message" rows ="10" cols="10" type="text" class="form-control <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="message" autocomplete="description" wire:model="message" placeholder="Entrer message text..."></textarea>

                     <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div> 
          </div>
            <!--Images field-->
            <div class="col-md-12">
              <div class="form-group">                  
                  <div wire:loading wire:target="image">Chargement...</div>
                     <div 
                     x-data="{ isUploading: false, progress: 0 }"
                     x-on:livewire-upload-start="isUploading = true"
                     x-on:livewire-upload-finish="isUploading = false"
                     x-on:livewire-upload-error="isUploading = false"
                     x-on:livewire-upload-progress="progress = $event.detail.progress"
                     >
                            <!--Input file-->
                    <input x-ref="fileInput" type="file" wire:model="image" class="hidden">
                   <div @click="$refs.fileInput.click()"><i class="fa fa-picture-o fa-4x" aria-hidden="true"></i>Choisir image
                      <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          
                            </div>
                            <!--Progress bar-->
                            <div x-show="isUploading">
                                <progress max="100" x-bind:value="progress"></progress>
                            </div>
                          </div>

                   <?php if($image): ?>
                     <?php $__currentLoopData = $image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex justify-center" wire:key="<?php echo e($loop->index); ?>">
                        <i class="fa fa-times-circle text-gray-700 text-2xl float-right cursor-pointer " wire:click="remove(<?php echo e($loop->index); ?>)"></i>
                       <img src="<?php echo e($img->temporaryUrl()); ?>" width="250">
                     </div>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     <?php endif; ?>
                  </div>
                </div>                
                    
         <div class="col-md-12">
            <button type="submit" class="btn btn-primary"><?php echo e(('Soumettre')); ?></button>
        </div>
     </div>  
   </form>
</div>
<?php /**PATH C:\Web\salut\resources\views/livewire/posts-user.blade.php ENDPATH**/ ?>