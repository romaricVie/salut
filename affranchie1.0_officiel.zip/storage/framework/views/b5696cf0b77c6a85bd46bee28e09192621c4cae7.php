<div>
   <div>
     <form enctype="multipart/form-data" id="image-upload-preview" wire:submit.prevent="save">
              <?php echo csrf_field(); ?>     
            <div class="row">
               <textarea cols="10" rows="5" placeholder="J'évangelise..." name="message" class="form-control"></textarea>
                <div class="col-md-12">
                    <div class="form-group">
                        <input type="file" name="image" placeholder="Choose image" id="image">
                        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                         <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                  
                <div class="col-md-12 mb-2">
                    <img id="preview-image" src="https://www.riobeauty.co.uk/images/product_image_not_found.gif"
                        alt="preview image" style="max-height: 250px;">
                </div>
                  
                <div class="col-md-12">
                    <button type="submit" class="btn btn-primary">Soumettre</button>
                </div>
            </div>     
        </form>
    </div>
</div>

<!--Upload Image with Preview-->
<script type="text/javascript">
    $('#image').change(function(){
           
    let reader = new FileReader();

    reader.onload = (e) => { 

      $('#preview-image').attr('src', e.target.result); 
    }

    reader.readAsDataURL(this.files[0]); 
  
   });
  </script><?php /**PATH C:\Web\salut\resources\views/livewire/post.blade.php ENDPATH**/ ?>