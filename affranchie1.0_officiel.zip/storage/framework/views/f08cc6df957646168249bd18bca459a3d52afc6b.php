<a href="/">
     <img class="h-10" src="<?php echo e(asset('/images/logo.svg')); ?>" alt="logo">
</a>
<?php /**PATH C:\Web\salut\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>