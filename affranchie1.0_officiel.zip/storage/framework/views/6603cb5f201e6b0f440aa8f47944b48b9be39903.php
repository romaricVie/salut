 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('title'); ?> 
           Don-en-finance
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
          <img src="<?php echo e(asset('/images/don.png')); ?>" class="h-10 w-10 inline"> Don en finance
        </h2>
     <?php $__env->endSlot(); ?>

   <main class="w-full min-h-screen pt-5 px-3 text-gray-600 bg-cover sm:px-10 sm:pt-40 pb-8 sm:px-8">
     <article class="max-w-screen-md mx-auto text-lg space-y-6">
        <h1 class="text-center text-3xl font-bold text-gray-900">Don en finance</h1>
        <section>
          <h2 class="text-center text-lg font-semibold text-gray-900 mb-4">Comptes Mobile Money</h2>
          <article class="flex items-center justify-center">
            <img src="<?php echo e(asset('/images/om.png')); ?>" alt="Numéro de compte Orange Money" class="w-24 h-auto">
            <img src="<?php echo e(asset('/images/flooz.png')); ?>" alt="Numéro de compte Flooz" class="w-24 h-auto mx-4">
            <img src="<?php echo e(asset('/images/momo.png')); ?>" alt="Numéro de compte MTN Mobile Money" class="w-24 h-auto">
          </article>
        </section>
        <section>
          <h2 class="text-center text-lg font-semibold text-gray-900">Compte bancaire</h2>
        </section>
      </article>
      </article>
    </main> 
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 


<?php /**PATH C:\Web\salut\resources\views/dons/finance.blade.php ENDPATH**/ ?>