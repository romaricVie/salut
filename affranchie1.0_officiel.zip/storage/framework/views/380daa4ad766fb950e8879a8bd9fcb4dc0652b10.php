<div class="row">
  <div class="col-md-12">
     <table class="table">
              <thead>
                <tr>
                  <th scope="col">#</th>
                  <th scope="col">Nom</th>
                  <th scope="col">Prenoms</th>
                  <th scope="col">Email</th>
                  <th scope="col">Roles</th>
                  <th scope="col">Actions</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($user->id); ?></th>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->firstname); ?></td>
                    <td><a href="mailto:<?php echo e($user->email); ?>"><?php echo e($user->email); ?></a></td>
                    <!--Récuperer les données sous forme de tableau-->
                    <td><?php echo e(implode(',',$user->roles()->get()->pluck('name')->toArray())); ?></td>
                    <td>
                      <!--Gates edit-users--->
                      
                            <a href="<?php echo e(route('admin.edit',$user)); ?>"><button class="btn btn-primary"><i class="fa fa-edit"></i> Editer</button></a>
                      
                       <!--Gates delete-users--->
                      
                          <form 
                           action=""
                           method="POST"
                           class="d-inline"
                           onsubmit ="return confirm('Etre vous sur de vouloir supprimer cet utilisateur?');"
                          >
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <a href=""><button class="btn btn-warning"><i class="fa fa-trash"></i> Supprimer</button></a>
                       </form>
                   </td>
                </tr>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </tbody>
        </table>
  </div>
</div><?php /**PATH C:\Web\salut\resources\views/admin/users/partials/_users_table.blade.php ENDPATH**/ ?>