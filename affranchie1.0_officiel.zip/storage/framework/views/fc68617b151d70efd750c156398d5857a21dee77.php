
 <?php $__env->startSection('content'); ?>

<?php if($dons->count()>0): ?>
 <h1 class="text-center">(<span style="color: red"><?php echo e($dons->count()); ?></span>) Don<?php echo e($dons->count() >1 ? 's' :''); ?> effectué par (<?php echo e($user->name); ?>)</h1>

<?php $__currentLoopData = $dons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $don): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div>
  <div class="max-w-screen-md mx-auto px-3 py-5 mb-3 shadow-sm hover:shadow-md rounded border-2 border-gray-300">
            <div class="mb-8">
                <a href="<?php echo e(route('profil.index',$don->user)); ?>" class="no-underline hover:no-underline focus:outline-none font-bold uppercase"><?php echo e($don->user->name.' '.$don->user->firstname); ?>

                </a><i> publié le <?php echo e($don->created_at); ?></i>
                 <img src="<?php echo e($don->user->profile_photo_url); ?>" title="Photo de profil de <?php echo e($don->user->firstname); ?>" class="h-20 w-20">
            </div>
           <div>
           <p class="text-base font-semibold break-all"><?=replace_links(nl2br($don->description))?>
           </p>
            
                <?php if($don->images): ?>
                 <div class="mb-8">
                   <a href="<?php echo e(asset('storage/'.$don->images)); ?>"><img src="<?php echo e(asset('storage/'.$don->images)); ?>"></a>
                 </div>
                <?php endif; ?> 
            </div>
            <div>
            <div>
               <h5><span class="badge badge-danger"><?php echo e($don->status); ?></span></h5>
               <a href="<?php echo e(route('admin.edit.dons',$don)); ?>" class="btn btn-primary"><i class="fa fa-edit"></i> Editer</a>
              <form 
              action="<?php echo e(route('admin.destroy.dons',$don)); ?>"
              method="POST"
              class="d-inline"
              onsubmit ="return confirm('Etre vous sur de vouloir supprimer cet don?');"
              >
              <?php echo csrf_field(); ?>
              <?php echo method_field('DELETE'); ?>
              <a href=""><button type="submit" class="btn btn-warning"><i class="fa fa-trash"></i> Supprimer</button></a>
          </form>
      </div>
      </div>
   </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  <?php else: ?>
  <div class="alert alert-primary alert-dismissible fade show" role="alert">
  <strong>Aucun dons disponible pour l'instant!</strong> 
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
 <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master',['title'=>'Don'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web\salut\resources\views/admin/dons/shows.blade.php ENDPATH**/ ?>