

 <?php $__env->startSection('content'); ?>
<h1 class="text-center">Demandes de prière  (<span style="color: red"><?php echo e($prieres->count()); ?></span>)</h1>
<?php if($prieres->count()>0): ?>
  <?php $__currentLoopData = $prieres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $priere): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div>
  <div class="max-w-screen-md mx-auto px-3 py-5 mb-3 shadow-sm hover:shadow-md rounded border-2 border-gray-300">
      <div class="mb-8">
              <a href="<?php echo e(route('profil.index',$priere->user)); ?>" class="no-underline hover:no-underline focus:outline-none"><span class="font-bold uppercase no-underline "><?php echo e($priere->user->name.' '.$priere->user->firstname); ?></span>
                </a>
                 <img src="<?php echo e($priere->user->profile_photo_url); ?>" title="Photo de profil de <?php echo e($priere->user->firstname); ?>" class="h-20 w-20">
                 <p>Voir sujest</p>
           </div>      
          
      </div>
 </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 
<?php else: ?>
 <div class="alert alert-primary alert-dismissible fade show" role="alert">
  <strong>Aucun poste disponible pour l'instant!</strong>
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?> 

<?php echo $__env->make('template.master',['title'=>'Demande de prière'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web\salut\resources\views/admin/priere/index.blade.php ENDPATH**/ ?>