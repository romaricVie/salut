 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('title'); ?> Verset-prefere <?php $__env->endSlot(); ?>
   <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.validation-errors','data' => ['class' => 'mb-4']]); ?>
<?php $component->withName('jet-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-4']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
  <section 
    class="max-w-screen-md mx-auto px-3 py-6 grid place-items-center text-gray-600"
  >

    <h1 class="text-center text-gray-800 font-bold mb-10 text-lg md:text-xl">Mon verset préféré</h1>

    <form 
      method="POST"
      action="<?php echo e(route('verset.store')); ?>"
      x-data="{ isFocused: false }" 
      x-cloak 
      class="w-full max-w-lg grid sm:grid-cols-3 gap-2"
    >
      <?php echo csrf_field(); ?>

      <div class="w-full mb-4 sm:col-span-1">
         <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['for' => 'book','value' => ''.e(__('Choisir livre *')).'']]); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'book','value' => ''.e(__('Choisir livre *')).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        <select  
          id="book" 
          name="book" 
          required
          class="w-full border border-transparent outline-none text-sm p-2 rounded-md mt-1 bg-white focus:bg-gray-300 focus:border-red-400"
        >
          <option value="">Livres...</option>
          <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($book->name); ?>"><?php echo e($book->name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>

      
      <!--chapitre field-->
      <div class="w-full mb-4 sm:col-span-1">
         <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['for' => 'chapter','value' => ''.e(__('Chapitre *')).'']]); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'chapter','value' => ''.e(__('Chapitre *')).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        <input 
          id="chapter" 
          class="w-full border border-transparent outline-none text-sm p-2 rounded-md mt-1 bg-white focus:bg-gray-300 focus:border-red-400" 
          type="number" 
          min="1"
          name="chapter"  
          aria-placeholder="Entrer chapitre" 
          required 
        />
      </div>

      <!--verset field-->
      <div class="w-full mb-4 sm:col-span-1">
         <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['for' => 'verse','value' => ''.e(__('Verset *')).'']]); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'verse','value' => ''.e(__('Verset *')).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        <input 
          id="verse" 
          class="w-full border border-transparent outline-none text-sm p-2 rounded-md mt-1 bg-white focus:bg-gray-300 focus:border-red-400" 
          type="number" 
          min="1"
          name="verse" 
          aria-placeholder="Entrer verset" 
          required 
          autocomplete="verse" 
        />
      </div>

      <div class="w-full mb-4 sm:col-span-3">
         <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['for' => 'text','value' => ''.e(__('Texte du verset*')).'']]); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'text','value' => ''.e(__('Texte du verset*')).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        <div 
          class="rounded-md border-transparent mt-1 overflow-hidden"
          :class="{ 'border border-red-400' : isFocused }"
        >
          <textarea
            id="text"
            name="text"
            class="w-full block resize-none rounded-md shadow-none bg-white font-haireline text-sm px-3 py-2 outline-none focus:bg-gray-300 "
            rows="6"
            aria-placeholder="Entrez votre sujet"
            @focusin="isFocused = true"
            @focusout="isFocused = false"
            required
          ><?php echo e(old('text')?? old('text')); ?></textarea>
        </div>
      </div>
       

      <button 
        type="submit" 
        class="sm:col-span-3 place-self-center mt-6 bg-red-600 py-2 px-5 rounded-md text-sm text-white font-semibold hover:bg-red-700 focus:bg-red-700"
      ><?php echo e(__('Enregistrer')); ?></button>
    </form>
  </section>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH C:\Web\salut\resources\views/verset-jour/create.blade.php ENDPATH**/ ?>