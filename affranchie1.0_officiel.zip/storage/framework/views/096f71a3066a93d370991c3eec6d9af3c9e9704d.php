

<?php $__env->startSection('content'); ?>
<div class="container">
  <h1>Création de poste pour admin</h1>
      <section id="post-admin">
        <div>
          <form method="POST" enctype="multipart/form-data" id="image-upload-preview" action="<?php echo e(route('admin.store.posts')); ?>">
               <?php echo csrf_field(); ?>
               <?php echo $__env->make('partials/_form',['textButton' =>'Admin Créer un message'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </form>
      </div>
    </section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web\salut\resources\views/admin/posts/create.blade.php ENDPATH**/ ?>