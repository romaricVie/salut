<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title><?php echo e(page_title($title ?? '')); ?></title>
        <link rel="icon" type="image/svg" href="<?php echo e(asset('/images/logo-img.svg')); ?>">
        <!-- Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">

        <!-- Styles -->
        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
        <link href="<?php echo e(asset('/assets/css/main.css')); ?>" rel="stylesheet" type="text/css">
         <style>
           [x-cloak] { display: none; }
        </style>

        <!-- Scripts -->
       <!--<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/assets/boots/css/bootstrap.min.css')); ?>">
       <script src="<?php echo e(asset('/assets/boots/js/bootstrap.min.js')); ?>"></script>-->
       
        <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.8.2/dist/alpine.min.js" defer></script>
        <script src="<?php echo e(asset('/assets/jquery/jquery-3.5.1.min.js')); ?>"></script>
         <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js" integrity="sha512-AA1Bzp5Q0K1KanKKmvN/4d3IRKVlv9PYgwFPvm32nPO6QS8yH1HO7LbgB1pgiOxPtfeg5zEn2ba64MUcqJx6CA==" crossorigin="anonymous"></script>
    </head>
    <body>
         <?php if(session('success')): ?>
                <script type="text/javascript">
                    swal("Félicitations!","<?php echo session('success'); ?>","success",{
                        button:"OK"
                    })
            </script>
        <?php endif; ?>
        <div class="font-sans text-gray-900 antialiased">
            <?php echo e($slot); ?>

        </div>
      <?php echo $__env->make('partials/_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    
    </body>
</html>
<?php /**PATH C:\Web\salut\resources\views/layouts/guest.blade.php ENDPATH**/ ?>