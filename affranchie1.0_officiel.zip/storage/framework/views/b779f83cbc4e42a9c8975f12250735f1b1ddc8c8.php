 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('title'); ?> Prière <?php $__env->endSlot(); ?>

  <section class="px-2 py-4">
    <article class="max-w-screen-md mx-auto mb-4 flex items-start rounded px-3 py-2 bg-blue-100 text-gray-900 mb-6">
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" class="w-4 h-4 mr-1 flex-shrink-0"><path d="M12,2C6.486,2,2,6.486,2,12s4.486,10,10,10s10-4.486,10-10S17.514,2,12,2z M12,20c-4.411,0-8-3.589-8-8s3.589-8,8-8 s8,3.589,8,8S16.411,20,12,20z"></path><path d="M11 11H13V17H11zM11 7H13V9H11z"></path></svg>
      <div>
        <h3 class="font-semibold text-gray-600 text-xs sm:text-sm leading-tight">Si vous avez des sujets de prière générale, Veuillez contacter  le departement intercession à l'adresse ci-dessous: <br/> <a href="mailto:intercession@affranchie.com" class="hover:underline">intercession@affranchie.com</a></h3>
        <br/>
        <p class="font-semibold text-gray-600 text-xs sm:text-sm leading-tight">NB:Chaque trois(3) jours de nouveaux sujets de prière seront disponibles.</p>
      </div>
    </article>

    <div>
      <div class="max-w-screen-md mx-auto p-5 mb-3 shadow-sm hover:shadow-md rounded-md bg-white">
        <div>
          <?php if(isset($intercession)): ?>
            <p class="text-sm sm:text-base font-semibold text-gray-600"><?=nl2br($intercession->subject)?></p>
          <?php else: ?>
            <p class="text-sm sm:text-base font-semibold text-gray-600">Pas de sujet disponible !</p>
          <?php endif; ?>
        </div>
       </div>
    </div>
  </section>
    

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH C:\Web\salut\resources\views/intercession/index.blade.php ENDPATH**/ ?>