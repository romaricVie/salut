<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

  <!-- Appel du head -->
  <?php echo $__env->make('template/partials/_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Body -->
  <body>
    <div class="min-h-screen w-full bg-white flex items-start">

      <!-- NAVIGATION -->
      <div 
        x-data="{}"
        class="h-screen w-auto py-4 sticky top-0 flex-shrink-0 flex overflow-y-hidden" style="background-color: #11142b;"
      >
        <button 
          class="focus:outline-none w-6 h-6 rounded-full bg-blue-500 grid place-items-center text-gray-100 absolute left-4 top-0 transform translate-y-2 z-10"
        >
          <span title="Réduire le menu" class="">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M15 19l-7-7 7-7"></path></svg>
          </span>
          <span title="agrandir le menu" class="hidden">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 5l7 7-7 7M5 5l7 7-7 7"></path></svg>
          </span>
        </button>

        <?php echo $__env->make('template/partials/_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>

      <!-- PAGE PRINCIPALE -->
      <div class="w-full min-h-screen bg-gray-200 overflow-x-hidden">
        <!-- LES ALERTS -->
          <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
              <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div>
          <?php endif; ?>

          <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
              <strong><?php echo e(session('success')); ?>!</strong>
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
          <?php endif; ?>

          <?php if(session('danger')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
              <strong><?php echo e(session('danger')); ?>!</strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
          <?php endif; ?>
        <!-- FIN ALERTS -->

        
        <!-- CONTENU PRINCIPAL -->
        <?php echo $__env->yieldContent('content'); ?>
        <!-- FIN CONTENU PRINCIPAL -->
      </div>
      <!-- FIN PAGE PRINCIPALE -->
      
    </div>
    

    <!-- Scripts -->
    <?php echo $__env->make('template/partials/_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('extra-js'); ?>
</body>
</html><?php /**PATH C:\Web\salut\resources\views/template/master.blade.php ENDPATH**/ ?>