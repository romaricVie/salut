

<?php $__env->startSection('content'); ?>

	<main class="px-10 pt-10 pb-6">
	    <h1 class="text-xl font-extrabold text-gray-700 mb-10">Gestion des utilisateurs (<span class="text-red-600"><?php echo e($membres->count()); ?></span>)</h1>

	    <section class="bg-white p-4 rounded-md">
	        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('users-manager')->html();
} elseif ($_instance->childHasBeenRendered('W2oHF0J')) {
    $componentId = $_instance->getRenderedChildComponentId('W2oHF0J');
    $componentTag = $_instance->getRenderedChildComponentTagName('W2oHF0J');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('W2oHF0J');
} else {
    $response = \Livewire\Livewire::mount('users-manager');
    $html = $response->html();
    $_instance->logRenderedChild('W2oHF0J', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
	    </section>
	</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master',['title'=>'Utilisateurs'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web\salut\resources\views/admin/users/index.blade.php ENDPATH**/ ?>