<div>
    <div>
        <?php echo e($slot); ?>

    </div>
</div>
<?php /**PATH C:\Web\salut\resources\views/vendor/jetstream/components/authentication-card.blade.php ENDPATH**/ ?>