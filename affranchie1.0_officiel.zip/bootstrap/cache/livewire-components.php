<?php return array (
  'enseignement' => 'App\\Http\\Livewire\\Enseignement',
  'event' => 'App\\Http\\Livewire\\Event',
  'like-post' => 'App\\Http\\Livewire\\LikePost',
  'like-publication' => 'App\\Http\\Livewire\\LikePublication',
  'members' => 'App\\Http\\Livewire\\Members',
  'search-member' => 'App\\Http\\Livewire\\SearchMember',
  'search-page' => 'App\\Http\\Livewire\\SearchPage',
  'temoignage' => 'App\\Http\\Livewire\\Temoignage',
  'users-manager' => 'App\\Http\\Livewire\\UsersManager',
);