
<!-- CRIPTS -->
<script src="{{asset('/assets/jquery/jquery-3.5.1.min.js')}}"></script>
<script src="{{asset('/assets/boots/js/bootstrap.min.js')}}"></script>

@livewireScripts
