<x-guest-layout>
        <x-slot name="title">
              a-propos
        </x-slot>
         
 @include('partials/_about')
</x-guest-layout>
