<x-guest-layout>
        <x-slot name="title">
              Charte d'utilisation
          </x-slot>
         @include('partials/_charte')
</x-guest-layout>
